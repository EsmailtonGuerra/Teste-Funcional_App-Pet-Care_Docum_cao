package com.example.petcareapp.ui.cartaoVacina;

public class MainModelCartaoVacina {
    String listaIdCartao;
    String listaNomeVacina;
    String listaDtVacina;


    public MainModelCartaoVacina(String listaIdCartao, String listaNomeVacina, String listaDtVacina) {
        this.listaIdCartao = listaIdCartao;
        this.listaNomeVacina = listaNomeVacina;
        this.listaDtVacina = listaDtVacina;
    }

    public String getListaIdCartao() {
        return listaIdCartao;
    }

    public String getListaNomeVacina() {
        return listaNomeVacina;
    }

    public String getListaDtVacina() {
        return listaDtVacina;
    }

}

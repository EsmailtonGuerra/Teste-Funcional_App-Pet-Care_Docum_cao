package com.example.petcareapp.ui.admGerenciarClinica;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link admGerenciarClinicaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class admGerenciarClinicaFragment extends Fragment {

    String emailUsuarioAtual, nomeClicadoClinica, cfmvClicadoClinica, telefoneClicadoClinica;
    Integer idUsuarioAtual, idClicadoClinica, idClinicaVerificarCfmv;
    boolean verificarLista = true;
    boolean verificarCfmv = false;

    EditText admEmailClinica, admNomeClinica, admTelefoneClinica, etPesquisarClinica,
            admAlterarSenhaClinica, admAlterarConfSenhaClinica, admAlterarEmailClinica, admCfmvClinica;
    ListView listaAllClinica;
    TextView admDeletarClinica;
    Button btAdmAlterarSenhaClinica, btAdmAlterarDadosClinica, btAdmAlterarEmailClinica;

    ArrayList<String> arrayListaAllClinica;
    ArrayList<String> arrayListaFiltradaClinica;

    ArrayAdapter<String> adapter;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public admGerenciarClinicaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment admGerenciarClinicaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static admGerenciarClinicaFragment newInstance(String param1, String param2) {
        admGerenciarClinicaFragment fragment = new admGerenciarClinicaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_adm_gerenciar_clinica, container, false);

        admEmailClinica = view.findViewById(R.id.admEmailClinica);
        admNomeClinica = view.findViewById(R.id.admNomeClinica);
        admCfmvClinica = view.findViewById(R.id.admCfmvClinica);
        admTelefoneClinica = view.findViewById(R.id.admTelefoneClinica);
        admDeletarClinica = view.findViewById(R.id.admDeletarClinica);
        etPesquisarClinica = view.findViewById(R.id.etPesquisarClinica);
        listaAllClinica = view.findViewById(R.id.listaAllClinica);
        btAdmAlterarSenhaClinica = view.findViewById(R.id.btAdmAlterarSenhaClinica);
        btAdmAlterarDadosClinica = view.findViewById(R.id.btAdmAlterarDadosClinica);
        btAdmAlterarEmailClinica = view.findViewById(R.id.btAdmAlterarEmailClinica);
        admAlterarSenhaClinica = view.findViewById(R.id.admAlterarSenhaClinica);
        admAlterarConfSenhaClinica = view.findViewById(R.id.admAlterarConfSenhaClinica);
        admAlterarEmailClinica = view.findViewById(R.id.admAlterarEmailClinica);

        admEmailClinica.setFocusable(false);
        admEmailClinica.setFocusableInTouchMode(false);
        admEmailClinica.setCursorVisible(false);
        admEmailClinica.setLongClickable(false);

        etPesquisarClinica.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                funPesquisarClinica(s.toString());
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        listaAllClinica.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String clickedClinica = "";

                // Verifica se a lista filtrada foi preenchida
                if (arrayListaFiltradaClinica != null && !arrayListaFiltradaClinica.isEmpty()) {
                    // Recuperando o item clicado da lista filtrada
                    clickedClinica = arrayListaFiltradaClinica.get(position);
                } else if (arrayListaAllClinica != null && !arrayListaAllClinica.isEmpty()) {
                    // Caso contrário, recupera o item clicado da lista completa
                    clickedClinica = arrayListaAllClinica.get(position);
                }

                // Dividindo os valores de `itemClicked` (se necessário)
                String[] parts = clickedClinica.split("\n"); // Divindo os valores usando o separador ' | '

                // Acessando os valores
                if (parts.length >= 5) {
                    idClicadoClinica = Integer.valueOf(parts[1]);
                    admEmailClinica.setText(parts[2]);
                    admNomeClinica.setText(parts[3]);
                    nomeClicadoClinica = parts[3];
                    admCfmvClinica.setText(parts[4]);
                    cfmvClicadoClinica = parts[4];
                    admTelefoneClinica.setText(parts[5]);
                    telefoneClicadoClinica = parts[5];
                    funAtivarCampos();
                    etPesquisarClinica.setText(null);
                }

                // Log para verificação
                Log.d("admGerenciarClinicaFragment", "ID Clínica: " + idClicadoClinica);
            }
        });

        btAdmAlterarDadosClinica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAdmAlterarDadosClinica();
            }
        });

        admDeletarClinica.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idClicadoClinica == null) {
                    Toast.makeText(getActivity(), "Nenhuma clínica selecionada!", Toast.LENGTH_SHORT).show();
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setMessage("Você tem certeza que deseja excluir a clínica " + nomeClicadoClinica + "?")
                            .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                            .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Confirmar"
                                    funDeletarClinica();
                                }
                            })
                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Cancelar"
                                }
                            });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funListaAllClinica();
        funDesativarCampos();
        funLimparCampos();
        etPesquisarClinica.setText(null);
    }

    public void funListaAllClinica() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM adm_info_clinica";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            arrayListaAllClinica= new ArrayList<>();

            while(rs.next()){
                arrayListaAllClinica.add("\n"+rs.getString("id_login") + "\n"+rs.getString("email") + "\n"+rs.getString("nome")
                        + "\n"+rs.getString("cfmv_crmv") + "\n"+rs.getString("telefone")+ "\n");
            }

            adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, arrayListaAllClinica);
            listaAllClinica.setAdapter(adapter);

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funPesquisarClinica(String termo) {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM adm_info_clinica WHERE " +
                    "unaccent(LOWER(email)) LIKE LOWER(?) OR unaccent(LOWER(nome)) LIKE LOWER(?) " +
                    "OR unaccent(LOWER(cfmv_crmv)) LIKE LOWER(?) OR telefone LIKE ?";
            PreparedStatement stmt = con.prepareStatement(sql);

            String filtro = "%" + termo.trim() + "%";
            for (int i = 1; i <= 4; i++) {
                stmt.setString(i, filtro);
            }

            // Agora usando a variável de classe
            arrayListaFiltradaClinica = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                arrayListaFiltradaClinica.add("\n" + rs.getString("id_login") +
                        "\n" + rs.getString("email") +
                        "\n" + rs.getString("nome") +
                        "\n" + rs.getString("cfmv_crmv") +
                        "\n" + rs.getString("telefone") + "\n");
            }

            adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, arrayListaFiltradaClinica);
            listaAllClinica.setAdapter(adapter);

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {
            Log.e("ErroPesquisaClinica", "Erro ao pesquisar clínica", e);
        }
    }

    public void funAdmAlterarDadosClinica() {
        String nomeClinica = admNomeClinica.getText().toString().trim();
        String cfmvClinica = admCfmvClinica.getText().toString().trim();
        String telefoneClinica = admTelefoneClinica.getText().toString().trim();

        idClinicaVerificarCfmv = null;

        if (!(admNomeClinica.isEnabled() && admCfmvClinica.isEnabled() && admTelefoneClinica.isEnabled())) {
            Toast.makeText(getActivity(), "Nenhuma clínica selecionada!", Toast.LENGTH_SHORT).show();
        } else {
            if (nomeClinica.isEmpty() || cfmvClinica.isEmpty() ||telefoneClinica.isEmpty()) {
                Toast.makeText(getActivity(), "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            } else {
                if (nomeClinica.equals(nomeClicadoClinica) && cfmvClinica.equals(cfmvClicadoClinica)
                        && telefoneClinica.equals(telefoneClicadoClinica)) {
                    Toast.makeText(getActivity(), "Nenhum dado alterado!", Toast.LENGTH_SHORT).show();
                } else {
                    if (!cfmvClinica.equals(cfmvClicadoClinica)) {
                        funVerificarCfmv();
                    }
                    if (verificarCfmv == true && (!idClicadoClinica.equals(idClinicaVerificarCfmv))) {
                        Toast.makeText(getActivity(), "O CFMV/CRMV Digitado já esta e uso!", Toast.LENGTH_SHORT).show();
                    } else {
                        try {
                            Connection con = ConexaoMysql.conectar();
                            String sql = "UPDATE clinica SET nome = ?, cfmv_crmv = ?, telefone = ? WHERE id_clinica = ?";
                            PreparedStatement stmt = con.prepareStatement(sql);
                            stmt.setString(1, nomeClinica);
                            stmt.setString(2, cfmvClinica);
                            stmt.setString(3, telefoneClinica);
                            stmt.setInt(4, idClicadoClinica);
                            stmt.executeUpdate();

                            stmt.close();
                            con.close();

                            funListaAllClinica();
                            funDesativarCampos();
                            funLimparCampos();

                            if (arrayListaFiltradaClinica != null) {
                                arrayListaFiltradaClinica.clear();
                            }
                            adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, arrayListaAllClinica);
                            listaAllClinica.setAdapter(adapter);

                            Toast.makeText(getActivity(), "Dados atualizados com sucesso!", Toast.LENGTH_SHORT).show();
                        } catch (Exception e) {
                            throw new RuntimeException(e);
                        }
                    }

                }
            }
        }
    }

    public void funVerificarCfmv() {
        verificarCfmv = false;
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_clinica, cfmv_crmv FROM clinica WHERE cfmv_crmv = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, admCfmvClinica.getText().toString().trim());
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                idClinicaVerificarCfmv = Integer.valueOf(rs.getString("id_clinica"));
                verificarCfmv = true;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funDeletarClinica() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "DELETE FROM login WHERE id_login = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idClicadoClinica);
            stmt.execute();

            stmt.close();
            con.close();

            funListaAllClinica();
            funDesativarCampos();
            funLimparCampos();

            idClicadoClinica = null;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funDesativarCampos() {
        admNomeClinica.setFocusable(false);
        admNomeClinica.setFocusableInTouchMode(false);
        admNomeClinica.setCursorVisible(false);
        admNomeClinica.setLongClickable(false);

        admCfmvClinica.setFocusable(false);
        admCfmvClinica.setFocusableInTouchMode(false);
        admCfmvClinica.setCursorVisible(false);
        admCfmvClinica.setLongClickable(false);

        admTelefoneClinica.setFocusable(false);
        admTelefoneClinica.setFocusableInTouchMode(false);
        admTelefoneClinica.setCursorVisible(false);
        admTelefoneClinica.setLongClickable(false);

        admAlterarSenhaClinica.setFocusable(false);
        admAlterarSenhaClinica.setFocusableInTouchMode(false);
        admAlterarSenhaClinica.setCursorVisible(false);
        admAlterarSenhaClinica.setLongClickable(false);

        admAlterarConfSenhaClinica.setFocusable(false);
        admAlterarConfSenhaClinica.setFocusableInTouchMode(false);
        admAlterarConfSenhaClinica.setCursorVisible(false);
        admAlterarConfSenhaClinica.setLongClickable(false);

        admAlterarEmailClinica.setFocusable(false);
        admAlterarEmailClinica.setFocusableInTouchMode(false);
        admAlterarEmailClinica.setCursorVisible(false);
        admAlterarEmailClinica.setLongClickable(false);
    }

    public void funAtivarCampos() {
        admNomeClinica.setFocusable(true);
        admNomeClinica.setFocusableInTouchMode(true);
        admNomeClinica.setCursorVisible(true);
        admNomeClinica.setLongClickable(true);

        admCfmvClinica.setFocusable(true);
        admCfmvClinica.setFocusableInTouchMode(true);
        admCfmvClinica.setCursorVisible(true);
        admCfmvClinica.setLongClickable(true);

        admTelefoneClinica.setFocusable(true);
        admTelefoneClinica.setFocusableInTouchMode(true);
        admTelefoneClinica.setCursorVisible(true);
        admTelefoneClinica.setLongClickable(true);

        admAlterarSenhaClinica.setFocusable(true);
        admAlterarSenhaClinica.setFocusableInTouchMode(true);
        admAlterarSenhaClinica.setCursorVisible(true);
        admAlterarSenhaClinica.setLongClickable(true);

        admAlterarConfSenhaClinica.setFocusable(true);
        admAlterarConfSenhaClinica.setFocusableInTouchMode(true);
        admAlterarConfSenhaClinica.setCursorVisible(true);
        admAlterarConfSenhaClinica.setLongClickable(true);

        admAlterarEmailClinica.setFocusable(true);
        admAlterarEmailClinica.setFocusableInTouchMode(true);
        admAlterarEmailClinica.setCursorVisible(true);
        admAlterarEmailClinica.setLongClickable(true);
    }

    public void funLimparCampos() {
        admEmailClinica.setText(null);
        admNomeClinica.setText(null);
        admCfmvClinica.setText(null);
        admTelefoneClinica.setText(null);
        admAlterarSenhaClinica.setText(null);
        admAlterarConfSenhaClinica.setText(null);
        idClicadoClinica = null;
    }

}
package com.example.petcareapp.ui.mensagem;

import android.graphics.Bitmap;

public class MainModelContato {

    String listaIdContato;
    Bitmap listaFotoContato;
    String listaNomeContato;

    public MainModelContato(String listaIdContato, Bitmap listaFotoContato, String listaNomeContato) {
        this.listaIdContato = listaIdContato;
        this.listaFotoContato = listaFotoContato;
        this.listaNomeContato = listaNomeContato;
    }

    public String getListaIdContato() {
        return listaIdContato;
    }

    public Bitmap getListaFotoContato() {
        return listaFotoContato;
    }

    public String getListaNomeContato() {
        return listaNomeContato;
    }
}


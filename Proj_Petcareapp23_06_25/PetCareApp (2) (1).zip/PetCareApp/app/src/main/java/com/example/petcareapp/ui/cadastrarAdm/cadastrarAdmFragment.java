package com.example.petcareapp.ui.cadastrarAdm;

import static android.view.View.GONE;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.CadastrarLoginActivity;
import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.LoginActivity;
import com.example.petcareapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link cadastrarAdmFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class cadastrarAdmFragment extends Fragment {

    String emailUsuarioAtual, idUsuarioAtual;

    EditText etEmailNovoAdm, etSenhaNovoAdm, etConfSenhaNovoAdm;
    Button btAdicionarNovoAdm;
    TextView tituloAddAdm;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public cadastrarAdmFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment cadastrarAdmFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static cadastrarAdmFragment newInstance(String param1, String param2) {
        cadastrarAdmFragment fragment = new cadastrarAdmFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cadastrar_adm, container, false);

        etEmailNovoAdm = view.findViewById(R.id.etEmailNovoAdm);
        etSenhaNovoAdm = view.findViewById(R.id.etSenhaNovoAdm);
        etConfSenhaNovoAdm = view.findViewById(R.id.etConfSenhaNovoAdm);
        btAdicionarNovoAdm =view.findViewById(R.id.btAdicionarNovoAdm);
        tituloAddAdm = view.findViewById(R.id.tituloAddAdm);

        btAdicionarNovoAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmailNovoAdm.getText().toString().trim();
                String senha = etSenhaNovoAdm.getText().toString().trim();
                String confSenha = etConfSenhaNovoAdm.getText().toString().trim();

                if (email.isEmpty() || senha.isEmpty()) {
                    Toast.makeText(getActivity(), "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else {
                    if(senha.equals(confSenha)){
                        // Cadastra usuário no Firebase/Banco de Dados SQL
                        funCadastrarUsuario(v);
                    } else{
                        Toast.makeText(getActivity(), "Senha e confirmação de senha não coincidem", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = rs.getString("id_login");
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funVerificaAdm();
    }

    // Função para cadastrar usuário no Firebase/Banco de Dados SQL
    public void funCadastrarUsuario(View v) {

        String email = etEmailNovoAdm.getText().toString().trim();
        String senha = etSenhaNovoAdm.getText().toString().trim();

        FirebaseAuth.getInstance().createUserWithEmailAndPassword(email, senha)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if (emailUsuarioAtual.equals("admin@admin.com") && idUsuarioAtual.equals("1")) {
                            if (task.isSuccessful()) {
                                // Cadastra usuário no Banco de Dados SQL
                                try {
                                    Connection con = ConexaoMysql.conectar();
                                    String sql = "INSERT INTO login(email, tipo_user)VALUES(?,?);";
                                    PreparedStatement stmt = con.prepareStatement(sql);
                                    stmt.setString(1, email);
                                    stmt.setString(2,"ADM");
                                    stmt.execute();

                                    stmt.close();
                                    con.close();

                                    // Depois do cadastro, desloga e vai para a tela de login
                                    FirebaseAuth.getInstance().signOut();
                                    Intent intent = new Intent(getActivity(), LoginActivity.class);
                                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    startActivity(intent);
                                    getActivity().finish();

                                } catch (Exception e) {
                                    throw new RuntimeException(e);
                                }
                            } else {
                                // Tratando erros
                                try {
                                    throw task.getException(); // Tenta obter uma exceção
                                } catch(FirebaseAuthWeakPasswordException e) { // Senha menor que 6 caracteres
                                    Toast.makeText(getActivity(), "A senha deve ter pelo menos 6 caracteres", Toast.LENGTH_SHORT).show();
                                } catch (FirebaseAuthUserCollisionException e) { // Caso o email já exista
                                    Toast.makeText(getActivity(), "E-mail já cadastrado, tente outro", Toast.LENGTH_SHORT).show();
                                } catch (FirebaseAuthInvalidCredentialsException e) { // Caso o email sejá inválido
                                    Toast.makeText(getActivity(), "Por favor, insira um e-mail válido", Toast.LENGTH_SHORT).show();
                                } catch (Exception e) {
                                    Toast.makeText(getActivity(), "Ocorreu um erro ao tentar realizar o cadastro. Tente novamente", Toast.LENGTH_SHORT).show();
                                }
                            }
                        } else {
                            Toast.makeText(getActivity(), "Acesso negado!", Toast.LENGTH_SHORT).show();
                        }

                    }
                });
    }

    public void funVerificaAdm() {
        if (!emailUsuarioAtual.equals("admin@admin.com") && !idUsuarioAtual.equals("1")) {
           funEsconderLayout();
        }
    }

    public void funEsconderLayout() {
        tituloAddAdm.setVisibility(GONE);
        etEmailNovoAdm.setVisibility(GONE);
        etSenhaNovoAdm.setVisibility(GONE);
        etConfSenhaNovoAdm.setVisibility(GONE);
        btAdicionarNovoAdm.setVisibility(GONE);
    }

}
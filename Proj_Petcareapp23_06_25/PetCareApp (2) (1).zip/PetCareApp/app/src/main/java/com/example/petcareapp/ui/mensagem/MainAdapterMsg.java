package com.example.petcareapp.ui.mensagem;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.petcareapp.R;

import java.util.ArrayList;

public class MainAdapterMsg extends RecyclerView.Adapter<MainAdapterMsg.ViewHolder> {
    ArrayList<MainModelMsg> mainModels;
    Context context;
    Integer idUsuarioAtual; // 👈 ID do usuário logado para alinhamento

    // Construtor com ID do usuário atual
    public MainAdapterMsg(Context context, ArrayList<MainModelMsg> mainModels, Integer idUsuarioAtual) {
        this.context = context;
        this.mainModels = mainModels;
        this.idUsuarioAtual = idUsuarioAtual;
    }

    @NonNull
    @Override
    public MainAdapterMsg.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_item_msg, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MainAdapterMsg.ViewHolder holder, int position) {
        MainModelMsg msg = mainModels.get(position);

        holder.nomeRemetente.setText(msg.getNomeRemetente());
        holder.mensagem.setText(msg.getListaMensagem());

        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) holder.bubbleLayout.getLayoutParams();

        if (msg.getIdRemetente().equals(idUsuarioAtual)) {
            // Enviada - alinha à direita
            holder.bubbleLayout.setBackgroundResource(R.drawable.bg_msg_enviada);
            params.gravity = Gravity.END;
        } else {
            // Recebida - alinha à esquerda
            holder.bubbleLayout.setBackgroundResource(R.drawable.bg_msg_recebida);
            params.gravity = Gravity.START;
        }

        holder.bubbleLayout.setLayoutParams(params);
    }

    @Override
    public int getItemCount() {
        return mainModels != null ? mainModels.size() : 0;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout bubbleLayout;
        TextView nomeRemetente;
        TextView mensagem;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            bubbleLayout = itemView.findViewById(R.id.bubbleLayout);  // Layout da bolha
            nomeRemetente = itemView.findViewById(R.id.nomeRemetente);
            mensagem = itemView.findViewById(R.id.mensagem);
        }
    }
}
package com.example.petcareapp.ui.perfilTutor;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;


import static android.app.ProgressDialog.show;
import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_LONG;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;


public class perfilTutorFragment extends Fragment {

    EditText  nomeTutor, descricaoTutor, telefoneTutor, dataNascimentoTutor;

    Button btnSalvar, btnEditar, btnSelecionarFoto;

    ImageButton btnCalendario;

    TextView dataSelecionada, countTextDescTutor;

    String dataBanco, idTutor;

    ImageView imagemTutor;

    String emailUsuarioAtual;

    Integer idUsuarioAtual;

    Bitmap imgOriginalBitmap;
    Bitmap selectedBitmap = null;
    boolean imageChanged = false; // Flag para indicar se a imagem foi alterada

    // Definindo o ActivityResultLauncher para capturar o resultado da seleção de foto
    private ActivityResultLauncher<Intent> selectPhotoLauncher;


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private static final int REQUEST_CODE_IMAGEM = 1;

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;
    private android.content.Intent Intent;

    public perfilTutorFragment() {
        // Required empty public constructor
    }

    public static perfilTutorFragment newInstance(String param1, String param2) {
        perfilTutorFragment fragment = new perfilTutorFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }

        // Inicializando o ActivityResultLauncher para a seleção de foto
        selectPhotoLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {

                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        // Recupera o URI da imagem selecionada
                        Intent data = result.getData();
                        Uri imageUri = data.getData();

                        if (imageUri != null) {
                            // Trabalhando com o URI
                            // String imageUriString = imageUri.toString();

                            // Convertendo o URI para um Bitmap:
                            try {
                                // Converte o URI para um Bitmap
                                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), imageUri);

                                // Armazenando no ImageView ou em uma variável global
                                imagemTutor.setImageBitmap(bitmap);
                                selectedBitmap = bitmap;  // Armazenando a imagem selecionada na variável global

                                // Atualizando a variável de controle de alteração de imagem
                                imageChanged = true;

                                if (btnSelecionarFoto.getAlpha() == 0) {
                                    btnSalvar.setVisibility(VISIBLE);
                                    btnEditar.setVisibility(GONE);
                                } else if (btnSelecionarFoto.getAlpha() == 1) {
                                    // Esconde o botão de selecionar a foto
                                }

                                // Verificando se a ImageView está vazia
                                Drawable drawable = imagemTutor.getDrawable();

                                if (drawable != null) {
                                    btnSelecionarFoto.setAlpha(0);
                                }
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
        );
    }

    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_perfil_tutor, container, false);
        CalendarView meuCalendario;
        String dia, mes, ano;

        imagemTutor = view.findViewById(R.id.imagemTutor);

        nomeTutor = view.findViewById(R.id.nomeTutor);
        descricaoTutor = view.findViewById(R.id.descricaoTutor);
        telefoneTutor = view.findViewById(R.id.telefoneTutor);
        dataNascimentoTutor = view.findViewById(R.id.dataNascimentoTutor);

        btnCalendario = view.findViewById(R.id.btnCalendario);
        meuCalendario = view.findViewById(R.id.meuCalendario);

        meuCalendario.setVisibility(GONE);

        btnSalvar = view.findViewById(R.id.btnSalvar);
        btnSalvar.setVisibility(GONE);
        btnEditar = view.findViewById(R.id.btnEditar);
        btnSelecionarFoto = view.findViewById(R.id.btnSelecionarFoto);

        countTextDescTutor = view.findViewById(R.id.countTextDescTutor);

        btnCalendario.setFocusable(false);
        btnCalendario.setFocusableInTouchMode(false);
        btnCalendario.setLongClickable(false);

        dataNascimentoTutor.setFocusable(false);
        dataNascimentoTutor.setFocusableInTouchMode(false);
        dataNascimentoTutor.setCursorVisible(false);
        dataNascimentoTutor.setLongClickable(false);

        funDesativarCampos();

        // Contador de caracteres
        descricaoTutor.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int currentLength = s.length();
                countTextDescTutor.setText(currentLength + "/300");
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        meuCalendario.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int ano, int meses, int dia) {
                int mes = meses+1;
                dataNascimentoTutor.setText(String.format("%02d/%02d/%04d", dia, mes, ano));
                meuCalendario.setVisibility(GONE);
                funMostrarLayout();
            }
        });

        btnEditar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtivarCampos();
            }
        });

        dataNascimentoTutor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                meuCalendario.setVisibility(VISIBLE);
                btnCalendario.setVisibility(GONE);
                btnSalvar.setVisibility(GONE);
                btnEditar.setVisibility(GONE);
                dataNascimentoTutor.setVisibility(GONE);
                telefoneTutor.setVisibility(GONE);
                nomeTutor.setVisibility(GONE);
                descricaoTutor.setVisibility(GONE);
                btnSelecionarFoto.setVisibility(GONE);
                imagemTutor.setVisibility(GONE);
                countTextDescTutor.setVisibility(GONE);
            }
        });

        btnSelecionarFoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funSelecionarFoto();
                funAtivarCampos();

            }
        });

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nomeTutor.getText().toString().trim();
                String descricao = descricaoTutor.getText().toString().trim();
                String telefone = telefoneTutor.getText().toString().trim();
                String dataNascimento = dataNascimentoTutor.getText().toString().trim();

                funAtualizarTutor();

                Drawable drawable = imagemTutor.getDrawable();

                if(drawable == null){
                    Toast.makeText(getContext(), "Adicione uma imagem do tutor", Toast.LENGTH_SHORT).show();
                }else if (nome.isEmpty() || descricao.isEmpty() || telefone.isEmpty() || dataNascimento.isEmpty()){
                    Toast.makeText(getContext(), "Preencha todos os campos !", Toast.LENGTH_SHORT).show();

                }else {
                    funAtualizarTutor();
                    funDesativarCampos();
                    imageChanged = false;
                }
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        Drawable drawable = imagemTutor.getDrawable();

        if(!(drawable == null)){
            btnEditar.setVisibility(GONE);
            btnSalvar.setVisibility(VISIBLE);
        }

        if(btnEditar.getVisibility() == VISIBLE){
            funBuscarTutor();
        }
    }

    public void funBuscarTutor() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "select * from tutor where id_tutor = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            Drawable drawable = imagemTutor.getDrawable();

            if (rs.next()){
                byte[] fotoBytes = rs.getBytes("foto");

                if (fotoBytes != null) {
                    btnSelecionarFoto.setAlpha(0);

                    //Converter a foto para Bitmap
                    Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0 , fotoBytes.length);

                    //Chama o metodo para arredondar a foto;
                    Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                    imagemTutor.setImageBitmap(roundedBitmap);
                }

                nomeTutor.setText(rs.getString("nome"));
                descricaoTutor.setText(rs.getString("descricao"));
                telefoneTutor.setText(rs.getString("telefone"));

                Date dataNascimento = rs.getDate("dt_nascimento");
                if (dataNascimento != null) {
                    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                    String dataFormatada = formato.format(dataNascimento);
                    dataNascimentoTutor.setText(dataFormatada);
                }
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException("Erro ao buscar dados do tutor", e);
        }

    }

    public void funSelecionarFoto() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        // ActivityResultLauncher para iniciar a atividade e capturar o resultado
        selectPhotoLauncher.launch(intent);
    }

    public Bitmap getRoundedBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int diameter = Math.min(width, height); // Tamanho do círculo

        // Criar um Bitmap novo com fundo transparente
        Bitmap output = Bitmap.createBitmap(diameter, diameter, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        // Criar um Paint com bordas suaves
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        // Desenhar um círculo na área onde queremos a imagem
        canvas.drawARGB(0, 0, 0, 0); // Fundo transparente
        canvas.drawCircle(diameter / 2, diameter / 2, diameter / 2, paint);

        // Usar a imagem com um efeito de máscara circular
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, (diameter - width) / 2, (diameter - height) / 2, paint);

        return output;
    }


    // Este método é chamado quando a foto é carregada (na seleção da foto)
    public void setImgOriginal(Bitmap bitmap) {
        imgOriginalBitmap = bitmap; // Armazena a imagem original para comparação posterior
        imageChanged = true; // Marca que a imagem foi alterada
    }

    // Método para recuperar a imagem do banco de dados
    private byte[] getImgBytesFromDatabase(String idTutor) {
        byte[] imgBytesAtual = null;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT foto FROM tutor WHERE id_tutor = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1,idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                imgBytesAtual = rs.getBytes("foto");
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return imgBytesAtual;
    }

    public void funAtualizarTutor() {
        String nome = nomeTutor.getText().toString().trim();
        String descricao = descricaoTutor.getText().toString().trim();
        String telefone = telefoneTutor.getText().toString().trim();
        String nascimento = dataNascimentoTutor.getText().toString().trim();

        // Se a imagem foi alterada
        byte[] imgBytes = null;
        if (imageChanged) {
            // Se uma nova imagem foi selecionada, converte para bytes
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            selectedBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
            imgBytes = byteArrayOutputStream.toByteArray();
        } else {
            // Caso a imagem não tenha sido alterada, recupere a imagem existente do banco de dados
            imgBytes = getImgBytesFromDatabase(idTutor);  // Supondo que você tenha um método para recuperar a imagem do banco
        }

        // Atualiza o banco de dados
        try {
            Connection con = ConexaoMysql.conectar();
            String sql;
            PreparedStatement stmt;

            if (imageChanged) {
                // Atualiza com a nova foto, caso tenha sido alterada
                sql = "update tutor set foto = ?, nome = ?, descricao = ? , telefone = ? , dt_nascimento = ? where id_tutor = ?;";
                stmt = con.prepareStatement(sql);

                // Converte a data de String para java.sql.Date com tratamento de erro
                java.sql.Date dataSql = null;
                try {
                    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                    Date dataUtil = formato.parse(nascimento); // String da data de nascimento
                    dataSql = new java.sql.Date(dataUtil.getTime());
                } catch (ParseException e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), "Data de nascimento inválida", Toast.LENGTH_SHORT).show();
                    return; // Encerra a execução se a data for inválida
                }

                stmt.setBytes(1,imgBytes);
                stmt.setString(2,nome);
                stmt.setString(3,descricao);
                stmt.setString(4,telefone);
                stmt.setDate(5, dataSql);
                stmt.setInt(6,idUsuarioAtual);
            } else {
                // Se a imagem não foi alterada, atualiza sem tocar na foto
                sql = "update tutor set nome = ?, descricao = ? , telefone = ? , dt_nascimento = ? where id_tutor = ?;";
                stmt = con.prepareStatement(sql);

                // Converte a data de String para java.sql.Date com tratamento de erro
                java.sql.Date dataSql = null;
                try {
                    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                    Date dataUtil = formato.parse(nascimento); // String da data de nascimento
                    dataSql = new java.sql.Date(dataUtil.getTime());
                } catch (ParseException e) {
                    e.printStackTrace();
                    Toast.makeText(getActivity(), "Data de nascimento inválida", Toast.LENGTH_SHORT).show();
                    return; // Encerra a execução se a data for inválida
                }

                stmt.setString(1,nome);
                stmt.setString(2,descricao);
                stmt.setString(3,telefone);
                stmt.setDate(4,dataSql);
                stmt.setInt(5,idUsuarioAtual);
            }

            stmt.executeUpdate();

            imageChanged = false;

            stmt.close();
            con.close();

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    public void funDesativarCampos(){
        nomeTutor.setFocusable(false);
        nomeTutor.setFocusableInTouchMode(false);
        nomeTutor.setCursorVisible(false);
        nomeTutor.setLongClickable(false);

        descricaoTutor.setFocusable(false);
        descricaoTutor.setFocusableInTouchMode(false);
        descricaoTutor.setCursorVisible(false);
        descricaoTutor.setLongClickable(false);

        telefoneTutor.setFocusable(false);
        telefoneTutor.setFocusableInTouchMode(false);
        telefoneTutor.setCursorVisible(false);
        telefoneTutor.setLongClickable(false);

        dataNascimentoTutor.setEnabled(false);
        btnSelecionarFoto.setEnabled(false);
        btnEditar.setVisibility(VISIBLE);
        btnSalvar.setVisibility(GONE);
    }

    public void funAtivarCampos(){
        nomeTutor.setFocusable(true);
        nomeTutor.setFocusableInTouchMode(true);
        nomeTutor.setCursorVisible(true);
        nomeTutor.setLongClickable(true);

        descricaoTutor.setFocusable(true);
        descricaoTutor.setFocusableInTouchMode(true);
        descricaoTutor.setCursorVisible(true);
        descricaoTutor.setLongClickable(true);

        telefoneTutor.setFocusable(true);
        telefoneTutor.setFocusableInTouchMode(true);
        telefoneTutor.setCursorVisible(true);
        telefoneTutor.setLongClickable(true);

        dataNascimentoTutor.setEnabled(true);
        btnSelecionarFoto.setEnabled(true);
        btnEditar.setVisibility(GONE);
        btnSalvar.setVisibility(VISIBLE);
    }

    public void funMostrarLayout() {
        nomeTutor.setVisibility(VISIBLE);
        descricaoTutor.setVisibility(VISIBLE);
        telefoneTutor.setVisibility(VISIBLE);
        btnSelecionarFoto.setVisibility(VISIBLE);
        btnSalvar.setVisibility(VISIBLE);
        imagemTutor.setVisibility(VISIBLE);
        dataNascimentoTutor.setVisibility(VISIBLE);
        countTextDescTutor.setVisibility(VISIBLE);
        btnCalendario.setVisibility(VISIBLE);
    }

}
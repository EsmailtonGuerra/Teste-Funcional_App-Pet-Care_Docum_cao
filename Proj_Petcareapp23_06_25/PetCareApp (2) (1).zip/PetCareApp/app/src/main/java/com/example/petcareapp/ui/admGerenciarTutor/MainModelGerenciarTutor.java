package com.example.petcareapp.ui.admGerenciarTutor;

import android.graphics.Bitmap;

public class MainModelGerenciarTutor {
    Integer listaIdGerenciarTutor;
    Bitmap listaFotoGerenciarTutor;
    String listaEmailGerenciarTutor;
    String listaNomeGerenciarTutor;

    public MainModelGerenciarTutor(Integer listaIdGerenciarTutor, Bitmap listaFotoGerenciarTutor, String listaEmailGerenciarTutor, String listaNomeGerenciarTutor) {
        this.listaIdGerenciarTutor = listaIdGerenciarTutor;
        this.listaFotoGerenciarTutor = listaFotoGerenciarTutor;
        this.listaEmailGerenciarTutor = listaEmailGerenciarTutor;
        this.listaNomeGerenciarTutor = listaNomeGerenciarTutor;
    }

    public Integer getListaIdGerenciarTutor() {
        return listaIdGerenciarTutor;
    }
    public Bitmap getListaFotoGerenciarTutor() {
        return listaFotoGerenciarTutor;
    }
    public String getListaEmailGerenciarTutor() {
        return listaEmailGerenciarTutor;
    }
    public String getListaNomeGerenciarTutor() {
        return listaNomeGerenciarTutor;
    }

}


package com.example.petcareapp.ui.seguranca;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.LoginActivity;
import com.example.petcareapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.EmailAuthProvider;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link segurancaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class segurancaFragment extends Fragment {

    String emailUsuarioAtual, idUsuarioAtual;

    EditText alterarMinhaSenhaAtualSenha, alterarMinhaNovaSenha, alterarMinhaNovaSenhaConfirmar;
    Button btAlterarMinhaSenha;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public segurancaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment segurancaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static segurancaFragment newInstance(String param1, String param2) {
        segurancaFragment fragment = new segurancaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_seguranca, container, false);

        alterarMinhaSenhaAtualSenha = view.findViewById(R.id.alterarMinhaSenhaAtualSenha);
        alterarMinhaNovaSenha = view.findViewById(R.id.alterarMinhaNovaSenha);
        alterarMinhaNovaSenhaConfirmar = view.findViewById(R.id.alterarMinhaNovaSenhaConfirmar);
        btAlterarMinhaSenha = view.findViewById(R.id.btAlterarMinhaSenha);

        btAlterarMinhaSenha.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAlterarSenha();
            }
        });
        
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = rs.getString("id_login");
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /*
    public void funAlterarEmail() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        String newEmail = alterarMeuNovoEmail.getText().toString().trim();
        String currentPassword = alterarMeuEmailAtualSenha.getText().toString().trim(); // Obtenha a senha atual do utilizador

        // Verificar se o novo email é igual ao atual
        if (newEmail.equalsIgnoreCase(user.getEmail())) {
            Toast.makeText(getActivity(), "O novo email é igual ao email atual.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verificar se a senha atual está vazia
        if (currentPassword.isEmpty()) {
            Toast.makeText(getActivity(), "Digite sua senha atual.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verificar se o novo email está vazio
        if (newEmail.isEmpty()) {
            Toast.makeText(getActivity(), "Digite um email.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verificar se o novo email já está em uso por outra conta
        if (funVerificarEmailExiste(true)) {
            Toast.makeText(getActivity(), "E-mail já está em uso por outra conta.", Toast.LENGTH_SHORT).show();
            return;
        }

        AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), currentPassword);

        user.reauthenticate(credential)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> reauthTask) {
                        if (reauthTask.isSuccessful()) {
                            // Reautenticação bem-sucedida, podemos atualizar o e-mail
                            user.verifyBeforeUpdateEmail(newEmail)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> updateTask) {
                                            if (updateTask.isSuccessful()) {
                                                Log.d("TAG", "Verification email sent to " + newEmail);
                                                funAlterarEmailBd();

                                                Toast.makeText(getActivity(), "Um email de verificação foi enviado para " + newEmail, Toast.LENGTH_LONG).show();

                                                // Faz logout do usuário para que ele faça login novamente
                                                FirebaseAuth.getInstance().signOut();

                                                // Redireciona para tela de login
                                                Intent intent = new Intent(getActivity(), LoginActivity.class);
                                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                                startActivity(intent);
                                                getActivity().finish();

                                            } else {
                                                // Tratamento de erros no update do email
                                                try {
                                                    throw updateTask.getException();
                                                } catch (FirebaseAuthUserCollisionException e) {
                                                    Toast.makeText(getActivity(), "E-mail já está em uso por outra conta.", Toast.LENGTH_SHORT).show();
                                                } catch (FirebaseAuthInvalidCredentialsException e) {
                                                    Toast.makeText(getActivity(), "E-mail inválido ou mal formatado.", Toast.LENGTH_SHORT).show();
                                                } catch (FirebaseAuthInvalidUserException e) {
                                                    Toast.makeText(getActivity(), "Usuário não encontrado ou desativado.", Toast.LENGTH_SHORT).show();
                                                } catch (Exception e) {
                                                    Toast.makeText(getActivity(), "Erro ao atualizar e-mail.", Toast.LENGTH_SHORT).show();
                                                }
                                            }
                                        }
                                    });
                        } else {
                            // Falha na reautenticação
                            try {
                                throw reauthTask.getException();
                            } catch (FirebaseAuthInvalidCredentialsException e) {
                                Toast.makeText(getActivity(), "Senha incorreta. Tente novamente.", Toast.LENGTH_SHORT).show();
                            } catch (FirebaseAuthInvalidUserException e) {
                                Toast.makeText(getActivity(), "Usuário não encontrado ou desativado.", Toast.LENGTH_SHORT).show();
                            } catch (Exception e) {
                                Toast.makeText(getActivity(), "Erro na reautenticação: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                            Log.e("TAG", "Erro na reautenticação do usuário.", reauthTask.getException());
                        }
                    }
                });
    }
    */

    public void funAlterarSenha() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        String senhaAtual = alterarMinhaSenhaAtualSenha.getText().toString().trim();
        String novaSenha = alterarMinhaNovaSenha.getText().toString().trim();
        String confNovaSenha = alterarMinhaNovaSenhaConfirmar.getText().toString().trim();

        // Verificar se a senha atual está vazia
        if (senhaAtual.isEmpty()) {
            Toast.makeText(getActivity(), "Digite sua senha atual.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verificar se a nova senha está vazia
        if (novaSenha.isEmpty() || confNovaSenha.isEmpty()) {
            Toast.makeText(getActivity(), "Digite a nova senha.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verificar se a nova senha atende a critérios mínimos (exemplo: 6 caracteres)
        if (novaSenha.length() < 6) {
            Toast.makeText(getActivity(), "A nova senha deve ter pelo menos 6 caracteres.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verificar se a nova senha é igual à atual
        if (novaSenha.equals(senhaAtual)) {
            Toast.makeText(getActivity(), "A nova senha não pode ser igual à senha atual.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verificar confirmar a nova senha
        if (!novaSenha.equals(confNovaSenha)) {
            Toast.makeText(getActivity(), "Confirme a nova senha.", Toast.LENGTH_SHORT).show();
            return;
        }

        // Reautenticação do usuário antes de alterar a senha
        AuthCredential credential = EmailAuthProvider.getCredential(user.getEmail(), senhaAtual);

        user.reauthenticate(credential).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> reauthTask) {
                if (reauthTask.isSuccessful()) {
                    // Reautenticação bem-sucedida, podemos alterar a senha
                    user.updatePassword(novaSenha).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> updateTask) {
                            if (updateTask.isSuccessful()) {
                                Toast.makeText(getActivity(), "Senha atualizada com sucesso. Faça login novamente.", Toast.LENGTH_LONG).show();

                                // Faz logout do usuário para que ele faça login novamente
                                FirebaseAuth.getInstance().signOut();

                                // Redireciona para tela de login
                                Intent intent = new Intent(getActivity(), LoginActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                getActivity().finish();
                            } else {
                                try {
                                    throw updateTask.getException();
                                } catch (FirebaseAuthWeakPasswordException e) {
                                    Toast.makeText(getActivity(), "A nova senha é muito fraca. Escolha uma senha mais forte.", Toast.LENGTH_SHORT).show();
                                } catch (FirebaseAuthInvalidUserException e) {
                                    Toast.makeText(getActivity(), "Usuário inválido ou desativado.", Toast.LENGTH_SHORT).show();
                                } catch (Exception e) {
                                    Toast.makeText(getActivity(), "Erro ao atualizar a senha: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        }
                    });
                } else {
                    try {
                        throw reauthTask.getException();
                    } catch (FirebaseAuthInvalidCredentialsException e) {
                        Toast.makeText(getActivity(), "Senha atual incorreta.", Toast.LENGTH_SHORT).show();
                    } catch (FirebaseAuthInvalidUserException e) {
                        Toast.makeText(getActivity(), "Usuário inválido ou desativado.", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        Toast.makeText(getActivity(), "Erro na reautenticação: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    /*
    public void funAlterarEmailBd() {
        String novoEmail = alterarMeuNovoEmail.getText().toString().trim();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "UPDATE login SET novo_email_pendente = ? WHERE id_login = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, novoEmail);
            stmt.setString(2, idUsuarioAtual);
            stmt.executeUpdate();

            stmt.close();
            con.close();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public boolean funVerificarEmailExiste(boolean emailExiste) {
        emailExiste = false;
        String newEmail = alterarMeuNovoEmail.getText().toString().trim();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT email FROM login WHERE email = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, newEmail);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
                emailExiste = true;
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return emailExiste;
    }
    */

    /*
    public void funAlterarSenhaBd() {
        String novaSenha = alterarMinhaNovaSenha.getText().toString().trim();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "UPDATE login SET senha = UPPER(md5(?)) WHERE id_login = ? AND email = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, novaSenha);
            stmt.setString(2, idUsuarioAtual);
            stmt.setString(3, emailUsuarioAtual);
            stmt.executeUpdate();

            stmt.close();
            con.close();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    */

    public void funAtivarCampos() {
        alterarMinhaSenhaAtualSenha.setFocusable(true);
        alterarMinhaSenhaAtualSenha.setFocusableInTouchMode(true);
        alterarMinhaSenhaAtualSenha.setCursorVisible(true);
        alterarMinhaSenhaAtualSenha.setLongClickable(true);

        alterarMinhaNovaSenha.setFocusable(true);
        alterarMinhaNovaSenha.setFocusableInTouchMode(true);
        alterarMinhaNovaSenha.setCursorVisible(true);
        alterarMinhaNovaSenha.setLongClickable(true);

        alterarMinhaNovaSenhaConfirmar.setFocusable(true);
        alterarMinhaNovaSenhaConfirmar.setFocusableInTouchMode(true);
        alterarMinhaNovaSenhaConfirmar.setCursorVisible(true);
        alterarMinhaNovaSenhaConfirmar.setLongClickable(true);
    }

    public void funDesativarCampos() {
        alterarMinhaSenhaAtualSenha.setFocusable(false);
        alterarMinhaSenhaAtualSenha.setFocusableInTouchMode(false);
        alterarMinhaSenhaAtualSenha.setCursorVisible(false);
        alterarMinhaSenhaAtualSenha.setLongClickable(false);

        alterarMinhaNovaSenha.setFocusable(false);
        alterarMinhaNovaSenha.setFocusableInTouchMode(false);
        alterarMinhaNovaSenha.setCursorVisible(false);
        alterarMinhaNovaSenha.setLongClickable(false);

        alterarMinhaNovaSenhaConfirmar.setFocusable(false);
        alterarMinhaNovaSenhaConfirmar.setFocusableInTouchMode(false);
        alterarMinhaNovaSenhaConfirmar.setCursorVisible(false);
        alterarMinhaNovaSenhaConfirmar.setLongClickable(false);
    }

    public void funLimparCampos() {
        alterarMinhaSenhaAtualSenha.setText(null);
        alterarMinhaNovaSenha.setText(null);
        alterarMinhaNovaSenhaConfirmar.setText(null);
    }

}
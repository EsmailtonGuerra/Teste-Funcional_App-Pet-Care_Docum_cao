package com.example.petcareapp.ui.cartaoVacina;

import android.graphics.Bitmap;

public class MainModelVacina {
    Bitmap listaFotoPetVac;
    String listaNomePetVac;
    String listaIdPetVac;

    public MainModelVacina(Bitmap listaFotoPetVac, String listaNomePetVac, String listaIdPetVac) {
        this.listaFotoPetVac = listaFotoPetVac;
        this.listaNomePetVac = listaNomePetVac;
        this.listaIdPetVac = listaIdPetVac;
    }

    public Bitmap getListaFotoPetVac() {
        return listaFotoPetVac;
    }

    public String getListaNomePetVac() {
        return listaNomePetVac;
    }
    public String getListaIdPetVac() {
        return listaIdPetVac;
    }

}

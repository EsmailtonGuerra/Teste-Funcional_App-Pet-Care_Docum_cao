package com.example.petcareapp.ui.campanha;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.widget.Toast.LENGTH_LONG;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.android.gms.common.server.response.FastParser;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link novaCampanhaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class novaCampanhaFragment extends Fragment {

    String emailUsuarioAtual, dataI,dataF,tipoData;
    Integer idUsuarioAtual, id_ac;
    CalendarView calendarioNova;
    EditText nomeCampanhaNova, descCampanhaNova, inicioCamapanhaNova, fimCamapanhaNova, fonteCampanhaNova,
            logradouroEndCampanhaNova, numeroEndCampanhaNova, cepEndCampanhaNova, bairroEndCampanhaNova,
            cidadeEndCampanhaNova, complementoEndCampanhaNova;
    TextView enderecoNova;
    Spinner estadoEndCampanhaNova;
    Button btCadastrarCampanhaNova;

    ArrayAdapter<String> adapter1; //Adaptador para Startar os dados da lista.
    List<String> estadoList;
    ImageButton btDataInicioNova,btDataFimNova;
    //Formatação data
    String dataStringI = "inicio_campanha", dataStringF = "fim_campanha"  ; // Exemplo da data quando vem do banco de dados
    Date dataInicio,dataFim ; // Converte uma String para um objeto Date

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public novaCampanhaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment novaCampanhaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static novaCampanhaFragment newInstance(String param1, String param2) {
        novaCampanhaFragment fragment = new novaCampanhaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_nova_campanha, container, false);

        nomeCampanhaNova = view.findViewById(R.id.nomeCampanhaNova);
        descCampanhaNova = view.findViewById(R.id.descCampanhaNova);
        inicioCamapanhaNova = view.findViewById(R.id.inicioCampanhaNova);
        fimCamapanhaNova = view.findViewById(R.id.fimCampanhaNova);
        fonteCampanhaNova = view.findViewById(R.id.fonteCampanhaNova);
        logradouroEndCampanhaNova = view.findViewById(R.id.logradouroEndCampanhaNova);
        numeroEndCampanhaNova = view.findViewById(R.id.numeroEndCampanhaNova);
        cepEndCampanhaNova = view.findViewById(R.id.cepEndCampanhaNova);
        bairroEndCampanhaNova = view.findViewById(R.id.bairroEndCampanhaNova);
        cidadeEndCampanhaNova = view.findViewById(R.id.cidadeEndCampanhaNova);
        complementoEndCampanhaNova = view.findViewById(R.id.complementoEndCampanhaNova);
        estadoEndCampanhaNova = view.findViewById(R.id.estadoEndCampanhaNova);
        calendarioNova=view.findViewById(R.id.calendarioNova);
        enderecoNova=view.findViewById(R.id.enderecoNova);
        btCadastrarCampanhaNova = view.findViewById(R.id.btCadastrarCampanhaNova);
        btDataInicioNova=view.findViewById(R.id.btDataInicioNova);
        btDataFimNova=view.findViewById(R.id.btDataFimNova);

        calendarioNova.setVisibility(GONE);

        // Criar a lista de estadoEndCampanha
        estadoList = Arrays.asList("Acre", "Alagoas", "Amapá", "Amazonas", "Bahia", "Ceará", "Distrito Federal",
                "Espírito Santo", "Goiás", "Maranhão", "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais", "Pará", "Paraíba",
                "Paraná", "Pernambuco", "Piauí", "Rio de Janeiro", "Rio Grande do Norte", "Rio Grande do Sul", "Rondônia",
                "Roraima", "Santa Catarina", "São Paulo", "Sergipe", "Tocantins");

        // Criar o ArrayAdapter e associar ao Spinner
        adapter1 = new ArrayAdapter<>(getActivity(), android.R.layout.simple_spinner_item, estadoList);
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        estadoEndCampanhaNova.setAdapter(adapter1);

        calendarioNova.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int ano, int meses, int dia) {

                if (tipoData.equals("inicio")) {
                    int mes = meses + 1;
                    inicioCamapanhaNova.setText(String.format("%02d/%02d/%04d", dia, mes, ano));
                    dataI = String.format("%04d-%02d-%02d 00:00:00", ano, mes, dia); // CORRETO
                } else if (tipoData.equals("fim")) {
                    int mes = meses + 1;
                    fimCamapanhaNova.setText(String.format("%02d/%02d/%04d", dia, mes, ano));
                    dataF = String.format("%04d-%02d-%02d 00:00:00", ano, mes, dia); // CORRETO
                }

                nomeCampanhaNova.setVisibility(VISIBLE);
                descCampanhaNova.setVisibility(VISIBLE);
                inicioCamapanhaNova.setVisibility(VISIBLE);
                fimCamapanhaNova.setVisibility(VISIBLE);
                fonteCampanhaNova.setVisibility(VISIBLE);
                enderecoNova.setVisibility(VISIBLE);
                logradouroEndCampanhaNova.setVisibility(VISIBLE);
                cepEndCampanhaNova.setVisibility(VISIBLE);
                numeroEndCampanhaNova.setVisibility(VISIBLE);
                bairroEndCampanhaNova.setVisibility(VISIBLE);
                cidadeEndCampanhaNova.setVisibility(VISIBLE);
                estadoEndCampanhaNova.setVisibility(VISIBLE);
                complementoEndCampanhaNova.setVisibility(VISIBLE);
                btDataInicioNova.setVisibility(VISIBLE);
                btDataFimNova.setVisibility(VISIBLE);
                calendarioNova.setVisibility(GONE);
                btCadastrarCampanhaNova.setVisibility(VISIBLE);
            }
        });

        btDataInicioNova.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipoData= "inicio";
                calendarioNova.setVisibility(VISIBLE);
                nomeCampanhaNova.setVisibility(GONE);
                descCampanhaNova.setVisibility(GONE);
                inicioCamapanhaNova.setVisibility(GONE);
                fimCamapanhaNova.setVisibility(GONE);
                fonteCampanhaNova.setVisibility(GONE);
                enderecoNova.setVisibility(GONE);
                logradouroEndCampanhaNova.setVisibility(GONE);
                cepEndCampanhaNova.setVisibility(GONE);
                numeroEndCampanhaNova.setVisibility(GONE);
                bairroEndCampanhaNova.setVisibility(GONE);
                cidadeEndCampanhaNova.setVisibility(GONE);
                estadoEndCampanhaNova.setVisibility(GONE);
                complementoEndCampanhaNova.setVisibility(GONE);
                btCadastrarCampanhaNova.setVisibility(GONE);
                btDataInicioNova.setVisibility(GONE);
                btDataFimNova.setVisibility(GONE);
            }
        });

        btDataFimNova.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipoData= "fim";
                calendarioNova.setVisibility(VISIBLE);
                nomeCampanhaNova.setVisibility(GONE);
                descCampanhaNova.setVisibility(GONE);
                inicioCamapanhaNova.setVisibility(GONE);
                fimCamapanhaNova.setVisibility(GONE);
                fonteCampanhaNova.setVisibility(GONE);
                enderecoNova.setVisibility(GONE);
                logradouroEndCampanhaNova.setVisibility(GONE);
                cepEndCampanhaNova.setVisibility(GONE);
                numeroEndCampanhaNova.setVisibility(GONE);
                bairroEndCampanhaNova.setVisibility(GONE);
                cidadeEndCampanhaNova.setVisibility(GONE);
                estadoEndCampanhaNova.setVisibility(GONE);
                complementoEndCampanhaNova.setVisibility(GONE);
                btCadastrarCampanhaNova.setVisibility(GONE);
                btDataInicioNova.setVisibility(GONE);
                btDataFimNova.setVisibility(GONE);
            }
        });

        btCadastrarCampanhaNova.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funCadastrarCampanha(view);
            }
        });

        return view;
    }

    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login, tipo_user FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        inicioCamapanhaNova.setEnabled(false);
        fimCamapanhaNova.setEnabled(false);

        //funDesativarCamposCampanhas();


    }
    public void funCadastrarCampanha(View view){
        String nome = nomeCampanhaNova.getText().toString().trim();
        String descricao = descCampanhaNova.getText().toString().trim();
        String fonte = fonteCampanhaNova.getText().toString().trim();
        String logradouro = logradouroEndCampanhaNova.getText().toString().trim();
        String numero = numeroEndCampanhaNova.getText().toString().trim();
        String complemento = complementoEndCampanhaNova.getText().toString().trim();
        String bairro = bairroEndCampanhaNova.getText().toString().trim();
        String cidade = cidadeEndCampanhaNova.getText().toString().trim();
        String cep = cepEndCampanhaNova.getText().toString().trim();
        String inicio = inicioCamapanhaNova.getText().toString().trim();
        String fim = fimCamapanhaNova.getText().toString().trim();

        if (!(nome.isEmpty()||descricao.isEmpty()||fonte.isEmpty()||logradouro.isEmpty()||
                numero.isEmpty()||complemento.isEmpty()||bairro.isEmpty()||cidade.isEmpty()||
                cep.isEmpty()||inicio.isEmpty()||fim.isEmpty())){
            try {
                Connection con = ConexaoMysql.conectar();
                /*id_alerta_campanha, nome_campanha, desc_campanha, inicio_campanha, fim_campanha, fonte_web, fk_id_clinica
                */
                String sql = "INSERT INTO alerta_campanhas(nome_campanha,desc_campanha,inicio_campanha,fim_campanha," +
                        "fonte_web,fk_id_clinica) VALUES(?,?,?,?,?,?);";
                PreparedStatement stmt = con.prepareStatement(sql);
                stmt.setString(1,nomeCampanhaNova.getText().toString());
                stmt.setString(2,descCampanhaNova.getText().toString());

                Timestamp timestampI = Timestamp.valueOf(dataI);
                stmt.setTimestamp(3,timestampI);

                Timestamp timestampF = Timestamp.valueOf(dataF);
                stmt.setTimestamp(4,timestampF);

                stmt.setString(5,fonteCampanhaNova.getText().toString());
                stmt.setInt(6,idUsuarioAtual);
                stmt.execute();

                sql="SELECT id_alerta_campanha FROM alerta_campanhas ORDER BY id_alerta_campanha DESC LIMIT 1;";
                stmt = con.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery();
                while (rs.next()){
                    id_ac = Integer.valueOf(rs.getString("id_alerta_campanha"));
                }

                /*id_endereco_campanha, logradouro, numero, complemento, bairro, cidade, cep, estado, fk_id_alerta_campanhas
                 */
                sql = "INSERT INTO endereco_campanha(logradouro,numero,complemento,bairro,cidade,cep,estado," +
                        "fk_id_alerta_campanhas) VALUES(?,?,?,?,?,?,?,?);";
                stmt = con.prepareStatement(sql);
                stmt.setString(1,logradouroEndCampanhaNova.getText().toString());
                stmt.setString(6,cepEndCampanhaNova.getText().toString());
                stmt.setString(2,numeroEndCampanhaNova.getText().toString());
                stmt.setString(4,bairroEndCampanhaNova.getText().toString());
                stmt.setString(5,cidadeEndCampanhaNova.getText().toString());
                stmt.setString(7,estadoEndCampanhaNova.getSelectedItem().toString());
                stmt.setString(3,complementoEndCampanhaNova.getText().toString());
                stmt.setInt(8,id_ac);
                stmt.execute();

                stmt.close();
                rs.close();
                con.close();

                NavController navController = Navigation.findNavController(view);
                navController.navigate(R.id.nav_cadastrar_campanha);

                Toast.makeText(getContext(), "Camapnha CADASTRADA com sucesso!!!", Toast.LENGTH_SHORT).show();

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
        else {
            Toast.makeText(getActivity(), "Preencha todos os campos para CADASTRAR nova campanha!", Toast.LENGTH_SHORT).show();
        }
    }

}
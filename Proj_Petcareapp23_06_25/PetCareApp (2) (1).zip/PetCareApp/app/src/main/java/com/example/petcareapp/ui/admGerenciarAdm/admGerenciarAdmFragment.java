package com.example.petcareapp.ui.admGerenciarAdm;

import static android.view.View.GONE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.google.firebase.auth.FirebaseAuth;

import org.w3c.dom.Text;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link admGerenciarAdmFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class admGerenciarAdmFragment extends Fragment {

    String emailUsuarioAtual, nomeClicadoAdm;
    Integer idUsuarioAtual, idClicadoAdm;
    boolean verificarLista = true;

    EditText admEmailAdm, admNomeAdm, etPesquisarAdm, admAlterarSenhaAdm, admAlterarConfSenhaAdm, admAlterarEmailAdm;
    TextView tvDadosAdm, tvAlterarEmailAdm, tvAlterarSenhaAdm;
    ListView listaAllAdm;
    TextView admDeletarAdm;
    Button btAdmAlterarSenhaAdm, btAdmAlterarDadosAdm, btAdmAlterarEmailAdm;

    ArrayList<String> arrayListaAllAdm;
    ArrayList<String> arrayListaFiltradaAdm;

    ArrayAdapter<String> adapter;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public admGerenciarAdmFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment admGerenciarAdmFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static admGerenciarAdmFragment newInstance(String param1, String param2) {
        admGerenciarAdmFragment fragment = new admGerenciarAdmFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_adm_gerenciar_adm, container, false);

        admEmailAdm = view.findViewById(R.id.admEmailAdm);
        admNomeAdm = view.findViewById(R.id.admNomeAdm);
        admDeletarAdm = view.findViewById(R.id.admDeletarAdm);
        etPesquisarAdm = view.findViewById(R.id.etPesquisarAdm);
        listaAllAdm = view.findViewById(R.id.listaAllAdm);
        btAdmAlterarSenhaAdm = view.findViewById(R.id.btAdmAlterarSenhaAdm);
        btAdmAlterarDadosAdm = view.findViewById(R.id.btAdmAlterarDadosAdm);
        btAdmAlterarEmailAdm = view.findViewById(R.id.btAdmAlterarEmailAdm);
        admAlterarSenhaAdm = view.findViewById(R.id.admAlterarSenhaAdm);
        admAlterarConfSenhaAdm = view.findViewById(R.id.admAlterarConfSenhaAdm);
        admAlterarEmailAdm = view.findViewById(R.id.admAlterarEmailAdm);
        tvAlterarSenhaAdm = view.findViewById(R.id.tvAlterarSenhaAdm);
        tvAlterarEmailAdm = view.findViewById(R.id.tvAlterarEmailAdm);
        tvDadosAdm = view.findViewById(R.id.tvDadosAdm);

        admEmailAdm.setFocusable(false);
        admEmailAdm.setFocusableInTouchMode(false);
        admEmailAdm.setCursorVisible(false);
        admEmailAdm.setLongClickable(false);

        etPesquisarAdm.addTextChangedListener(new TextWatcher() {
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                funPesquisarAdm(s.toString());
            }

            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void afterTextChanged(Editable s) {}
        });

        listaAllAdm.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String clickedAdm = "";

                // Verifica se a lista filtrada foi preenchida
                if (arrayListaFiltradaAdm != null && !arrayListaFiltradaAdm.isEmpty()) {
                    // Recuperando o item clicado da lista filtrada
                    clickedAdm = arrayListaFiltradaAdm.get(position);
                } else if (arrayListaAllAdm != null && !arrayListaAllAdm.isEmpty()) {
                    // Caso contrário, recupera o item clicado da lista completa
                    clickedAdm = arrayListaAllAdm.get(position);
                }

                // Dividindo os valores de `itemClicked` (se necessário)
                String[] parts = clickedAdm.split("\n"); // Divindo os valores usando o separador ' | '

                // Acessando os valores
                if (parts.length >= 3) {
                    idClicadoAdm = Integer.valueOf(parts[1]);
                    admEmailAdm.setText(parts[2]);
                    admNomeAdm.setText(parts[3]);
                    nomeClicadoAdm = parts[3];
                    funAtivarCampos();
                    etPesquisarAdm.setText(null);
                }

                // Log para verificação
                Log.d("admGerenciarAdmFragment", "ID ADM: " + idClicadoAdm);
            }
        });

        btAdmAlterarDadosAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAdmAlterarDadosAdm();
            }
        });

        admDeletarAdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (idClicadoAdm == null) {
                    Toast.makeText(getActivity(), "Nenhum administrador selecionado!", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (idClicadoAdm.equals("1")) {
                    Toast.makeText(getActivity(), "Você não tem permissão para excluir esse administrador!", Toast.LENGTH_SHORT).show();
                } else {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    builder.setMessage("Você tem certeza que deseja excluir o administrador " + nomeClicadoAdm + "?")
                            .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                            .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Confirmar"
                                    funDeletarAdm();
                                }
                            })
                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    // Ação ao clicar em "Cancelar"
                                }
                            });

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funListaAllAdm();
        funDesativarCampos();
        funLimparCampos();
        etPesquisarAdm.setText(null);
    }

    public void funListaAllAdm() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM adm_info_adm";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            arrayListaAllAdm= new ArrayList<>();

            while(rs.next()){
                arrayListaAllAdm.add("\n"+rs.getString("id_login") + "\n"+rs.getString("email") + "\n"+rs.getString("nome") + "\n");
            }

            adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, arrayListaAllAdm);
            listaAllAdm.setAdapter(adapter);

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funPesquisarAdm(String termo) {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM adm_info_adm WHERE " +
                    "unaccent(LOWER(email)) LIKE LOWER(?) OR unaccent(LOWER(nome)) LIKE LOWER(?)";
            PreparedStatement stmt = con.prepareStatement(sql);

            String filtro = "%" + termo.trim() + "%";
            for (int i = 1; i <= 2; i++) {
                stmt.setString(i, filtro);
            }

            // Agora usando a variável de classe
            arrayListaFiltradaAdm = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                arrayListaFiltradaAdm.add("\n" + rs.getString("id_login") +
                        "\n" + rs.getString("email") +
                        "\n" + rs.getString("nome") + "\n");
            }

            adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, arrayListaFiltradaAdm);
            listaAllAdm.setAdapter(adapter);

            rs.close();
            stmt.close();
            con.close();

        } catch (Exception e) {
            Log.e("ErroPesquisaAdm", "Erro ao pesquisar administrador", e);
        }
    }

    public void funAdmAlterarDadosAdm() {
        String nomeAdm = admNomeAdm.getText().toString().trim();

        if (!(admNomeAdm.isEnabled())) {
            Toast.makeText(getActivity(), "Nenhum administrador selecionado!", Toast.LENGTH_SHORT).show();
        } else {
            if (nomeAdm.isEmpty()) {
                Toast.makeText(getActivity(), "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
            } else {
                if (nomeAdm.equals(nomeClicadoAdm)) {
                    Toast.makeText(getActivity(), "Nenhum dado alterado!", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        Connection con = ConexaoMysql.conectar();
                        String sql = "UPDATE adm SET nome = ? WHERE id_adm = ?";
                        PreparedStatement stmt = con.prepareStatement(sql);
                        stmt.setString(1, nomeAdm);
                        stmt.setInt(2, idClicadoAdm);
                        stmt.executeUpdate();

                        stmt.close();
                        con.close();

                        funListaAllAdm();
                        funDesativarCampos();
                        funLimparCampos();

                        if (arrayListaFiltradaAdm != null) {
                            arrayListaFiltradaAdm.clear();
                        }
                        adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_list_item_1, arrayListaAllAdm);
                        listaAllAdm.setAdapter(adapter);

                        Toast.makeText(getActivity(), "Dados atualizados com sucesso!", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                    }

                }
            }
        }

    public void funDeletarAdm() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "DELETE FROM login WHERE id_login = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idClicadoAdm);
            stmt.execute();

            stmt.close();
            con.close();

            funListaAllAdm();
            funDesativarCampos();
            funLimparCampos();

            idClicadoAdm = null;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funDesativarCampos() {
        admNomeAdm.setFocusable(false);
        admNomeAdm.setFocusableInTouchMode(false);
        admNomeAdm.setCursorVisible(false);
        admNomeAdm.setLongClickable(false);

        admAlterarSenhaAdm.setFocusable(false);
        admAlterarSenhaAdm.setFocusableInTouchMode(false);
        admAlterarSenhaAdm.setCursorVisible(false);
        admAlterarSenhaAdm.setLongClickable(false);

        admAlterarConfSenhaAdm.setFocusable(false);
        admAlterarConfSenhaAdm.setFocusableInTouchMode(false);
        admAlterarConfSenhaAdm.setCursorVisible(false);
        admAlterarConfSenhaAdm.setLongClickable(false);

        admAlterarEmailAdm.setFocusable(false);
        admAlterarEmailAdm.setFocusableInTouchMode(false);
        admAlterarEmailAdm.setCursorVisible(false);
        admAlterarEmailAdm.setLongClickable(false);
    }

    public void funAtivarCampos() {
        admNomeAdm.setFocusable(true);
        admNomeAdm.setFocusableInTouchMode(true);
        admNomeAdm.setCursorVisible(true);
        admNomeAdm.setLongClickable(true);

        admAlterarSenhaAdm.setFocusable(true);
        admAlterarSenhaAdm.setFocusableInTouchMode(true);
        admAlterarSenhaAdm.setCursorVisible(true);
        admAlterarSenhaAdm.setLongClickable(true);

        admAlterarConfSenhaAdm.setFocusable(true);
        admAlterarConfSenhaAdm.setFocusableInTouchMode(true);
        admAlterarConfSenhaAdm.setCursorVisible(true);
        admAlterarConfSenhaAdm.setLongClickable(true);

        admAlterarEmailAdm.setFocusable(true);
        admAlterarEmailAdm.setFocusableInTouchMode(true);
        admAlterarEmailAdm.setCursorVisible(true);
        admAlterarEmailAdm.setLongClickable(true);
    }

    public void funLimparCampos() {
        admEmailAdm.setText(null);
        admNomeAdm.setText(null);
        admAlterarSenhaAdm.setText(null);
        admAlterarConfSenhaAdm.setText(null);
        idClicadoAdm = null;
    }

    public void funEsconderLayout() {
        admEmailAdm.setVisibility(GONE);
        admNomeAdm.setVisibility(GONE);
        admDeletarAdm.setVisibility(GONE);
        etPesquisarAdm.setVisibility(GONE);
        listaAllAdm.setVisibility(GONE);
        btAdmAlterarSenhaAdm.setVisibility(GONE);
        btAdmAlterarDadosAdm.setVisibility(GONE);
        btAdmAlterarEmailAdm.setVisibility(GONE);
        admAlterarSenhaAdm.setVisibility(GONE);
        admAlterarConfSenhaAdm.setVisibility(GONE);
        admAlterarEmailAdm.setVisibility(GONE);
        tvDadosAdm.setVisibility(GONE);
        tvAlterarEmailAdm.setVisibility(GONE);
        tvAlterarSenhaAdm.setVisibility(GONE);
    }

    public void funVerificarAdm(boolean verificarAdm) {
        String idAdm = "";
        String emailAdm = "";

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login, email FROM login LIMIT 1";
            PreparedStatement stmt = con.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while(rs.next()) {
                idAdm = rs.getString("id_login");
                emailAdm = rs.getString("email");
            }

            if (idAdm.equals(idUsuarioAtual) && emailAdm.equals(emailUsuarioAtual)) {
                funEsconderLayout();
                verificarAdm = true;
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
package com.example.petcareapp.ui.pet;

import android.graphics.Bitmap;

public class MainModel {
    Bitmap listaFotoPet;
    String listaIdPet;
    String listaNomePet;

    public MainModel(Bitmap listaFotoPet, String listaIdPet, String listaNomePet) {
        this.listaFotoPet = listaFotoPet;
        this.listaIdPet = listaIdPet;
        this.listaNomePet = listaNomePet;
    }

    public Bitmap getListaFotoPet() {
        return listaFotoPet;
    }

    public String getListaIdPet() {
        return listaIdPet;
    }

    public String getListaNomePet() {
        return listaNomePet;
    }

}

package com.example.petcareapp.ui.cartaoVacina;

import static android.view.View.GONE;
import static android.view.View.VISIBLE;
import static android.view.View.generateViewId;
import static android.widget.Toast.LENGTH_LONG;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.petcareapp.ConexaoMysql;
import com.example.petcareapp.R;
import com.example.petcareapp.ui.pet.MainModel;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link cartaoVacinaFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class cartaoVacinaFragment extends Fragment {

    String emailUsuarioAtual, especieSelecionada, nomeVacinaClicada;
    String ultimaEspecieSelecionada = "";
    Integer idUsuarioAtual, idPetClicadoVac, idCartaoClicado, idPetClicado;

    RecyclerView listaVacina, listaCartaoVacina, listaPets;

    EditText nome_vacina, dt_vacinacao, lote_vacina, medico_vet, clinica_vet;

    Button btSalvarVacina, btAtualizarVacina, btAlterarVacina, btDeletarVacina;

    ImageView btAddNovaVacina;

    Spinner filtrarEspecieVac, spinnerFiltrarAllVacinas, spinnerFiltrarVacinasClick;

    TextView tvFiltrarEspecieVac, tvPetNull, tvVacinas, tvNovaVacina,
            tvVacina, tvNomeVacina, tvLoteVacina, tvDataVacina, tvMedicoVet, tvClinicaVet;

    boolean petIsNull = true;
    boolean vacinaIsNull = true;
    boolean verificarBt;
    boolean primeiraSelecaoSpinner = true; // Flag para ignorar primeira seleção do spinner quando ele e carregado

    ArrayList<String> listaNomePetVac = new ArrayList<>();
    ArrayList<Bitmap> listaFotoPetVac = new ArrayList<>();
    ArrayList<String> listaIdPetVac = new ArrayList<>();


    // Recylerview Cartao Vacina
    ArrayList<String> listaIdCartao = new ArrayList<>();
    ArrayList<String> listaNomeCartao = new ArrayList<>();
    ArrayList<String> listadtVacina = new ArrayList<>();

    // Recylerview Lista Pets
    ArrayList<Integer> listaIdPetVac1 = new ArrayList<>();
    ArrayList<Integer> listaIdCartaoVac1 = new ArrayList<>();
    ArrayList<Bitmap> listaFotoPetVac1 = new ArrayList<>();
    ArrayList<String> listaNomePetVac1 = new ArrayList<>();
    ArrayList<String> listaNomeVacinaVac1 = new ArrayList<>();
    ArrayList<String> listaDtVacinaVac1 = new ArrayList<>();

    ArrayList<MainModelVacina> mainModels = new ArrayList<>();
    ArrayList<MainModelCartaoVacina> mainModelsCartao = new ArrayList<>();
    ArrayList<MainModelLista> mainModelsPets = new ArrayList<>();

    MainAdapterVacina mainAdapter;
    MainAdapterCartaoVacina mainAdapterCartao;
    MainAdapterLista mainAdapterLista;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public cartaoVacinaFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment cartaoVacinaFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static cartaoVacinaFragment newInstance(String param1, String param2) {
        cartaoVacinaFragment fragment = new cartaoVacinaFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cartao_vacina, container, false);

        tvFiltrarEspecieVac = view.findViewById(R.id.tvFiltrarEspecieVac);
        filtrarEspecieVac = view.findViewById(R.id.filtrarEspecieVac);
        nome_vacina = view.findViewById(R.id.nome_vacina);
        dt_vacinacao = view.findViewById(R.id.dt_vacinacao);
        lote_vacina = view.findViewById(R.id.lote_vacina);
        medico_vet = view.findViewById(R.id.medico_vet);
        clinica_vet = view.findViewById(R.id.clinica_vet);
        btSalvarVacina = view.findViewById(R.id.btSalvarVacina);
        btAddNovaVacina = view.findViewById(R.id.btAddNovaVacina);
        listaVacina = view.findViewById(R.id.listaVacina);
        listaCartaoVacina = view.findViewById(R.id.listaCartaoVacina);
        listaPets = view.findViewById(R.id.listaPets);
        tvVacinas = view.findViewById(R.id.tvVacinas);
        tvPetNull = view.findViewById(R.id.tvPetNull);
        tvNovaVacina = view.findViewById(R.id.tvNovaVacina);
        btAtualizarVacina = view.findViewById(R.id.btAtualizarVacina);
        btAlterarVacina = view.findViewById(R.id.btAlterarVacina);
        tvVacina = view.findViewById(R.id.tvVacina);
        btDeletarVacina = view.findViewById(R.id.btDeletarVacina);
        tvNomeVacina = view.findViewById(R.id.tvNomeVacina);
        tvLoteVacina = view.findViewById(R.id.tvLoteVacina);
        tvDataVacina = view.findViewById(R.id.tvDataVacina);
        tvMedicoVet = view.findViewById(R.id.tvMedicoVet);
        tvClinicaVet = view.findViewById(R.id.tvClinicaVet);
        spinnerFiltrarVacinasClick = view.findViewById(R.id.spinnerfiltrarVacinasClick);
        spinnerFiltrarAllVacinas = view.findViewById(R.id.spinnerfiltrarAllVacinas);

        // Aplica o filtro de validação
        dt_vacinacao.setFilters(new InputFilter[]{ new DateInputFilter() });

        dt_vacinacao.addTextChangedListener(new TextWatcher() {
            private boolean isUpdating;

            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}

            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (isUpdating) return;

                // Remove caracteres não numéricos
                String clean = s.toString().replaceAll("[^\\d]", "");
                if (clean.length() > 8) clean = clean.substring(0, 8);

                StringBuilder out = new StringBuilder();
                for (int i = 0; i < clean.length(); i++) {
                    out.append(clean.charAt(i));
                    if ((i == 1 || i == 3) && i != clean.length() - 1) out.append('/');
                }

                isUpdating = true;
                dt_vacinacao.setText(out.toString());
                dt_vacinacao.setSelection(out.length());
                isUpdating = false;
            }
        });

        // Cria a lista de opções spinner All Vacinas
        String[] opcoesAllVacinas = {"Selecione", "Próximas", "Aplicadas", "Todas"};

        // Cria um adapter e define no Spinner
        ArrayAdapter<String> adapterAllVacinas = new ArrayAdapter<>(
                getContext(), // ou this se for Activity
                android.R.layout.simple_spinner_item,
                opcoesAllVacinas
        );
        adapterAllVacinas.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFiltrarAllVacinas.setAdapter(adapterAllVacinas);

        // Evitar que o onItemSelected dispare logo na criação
        //spinnerFiltrarAllVacinas.setSelection(0, /* animate = */ false);

        spinnerFiltrarAllVacinas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            private boolean firstTime = true;   // Para ignorar a primeira chamada automática spinner ListaPets

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (firstTime) {               // Ignora a primeira vez
                    firstTime = false;
                    return;
                }

                switch (position) {
                    case 1:  // "Próximas"
                        funListaCartaoProximasAll();
                        break;

                    case 2:  // "Aplicadas"
                        funListaCartaoAplicadasAll();
                        break;

                    case 3:  // "Todas"
                        funListaAllVacinas();
                        break;

                    // posição 0 é "Selecione" não faz nada
                    default:
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Nada a fazer aqui
            }
        });

        // Cria a lista de opções spinner Vacinas Click
        String[] opcoesClickVacinas = {"Selecione", "Próximas", "Aplicadas", "Todas"};

        // Cria um adapter e define no Spinner
        ArrayAdapter<String> adapterClickVacinas = new ArrayAdapter<>(
                getContext(), // ou this se for Activity
                android.R.layout.simple_spinner_item,
                opcoesAllVacinas
        );
        adapterAllVacinas.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFiltrarVacinasClick.setAdapter(adapterClickVacinas);

        // Evitar que o onItemSelected dispare logo na criação
        //spinnerFiltrarAllVacinas.setSelection(0, /* animate = */ false);

        spinnerFiltrarVacinasClick.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            private boolean firstTimeclick = true;   // Para ignorar a primeira chamada automática spinner ListaPets

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (firstTimeclick) {               // Ignora a primeira vez
                    firstTimeclick = false;
                    return;
                }

                switch (position) {
                    case 1:  // "Próximas"
                        funListaCartaoProximas();
                        break;

                    case 2:  // "Aplicadas"
                        funListaCartaoAplicadas();
                        break;

                    case 3:  // "Todas"
                        funListaPets();
                       funMostrarAllVacinas();
                        break;

                    // posição 0 é "Selecione" não faz nada
                    default:
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Nada a fazer aqui
            }
        });

        // Design Horizontal Layout
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.HORIZONTAL,false
        );
        listaVacina.setLayoutManager(layoutManager);
        listaVacina.setItemAnimator(new DefaultItemAnimator());

        // Design Horizontal Layout Cartao Vacina
        LinearLayoutManager layoutManagerCartao = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaCartaoVacina.setLayoutManager(layoutManagerCartao);
        listaCartaoVacina.setItemAnimator(new DefaultItemAnimator());

        // Design Horizontal Layout Lista Pets
        LinearLayoutManager layoutManagerLista = new LinearLayoutManager(
                getActivity(),LinearLayoutManager.VERTICAL,false
        );
        listaPets.setLayoutManager(layoutManagerLista);
        listaPets.setItemAnimator(new DefaultItemAnimator());

        mainAdapter = new MainAdapterVacina(getActivity(), mainModels, new MainAdapterVacina.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelVacina model) {
                // Obtenha o nome do pet do modelo
                idPetClicadoVac = Integer.valueOf(model.getListaIdPetVac());

                // Sempre chamar funListaCartao para atualizar vacinaIsNull e a lista de cartão
                funListaCartao();

                if (vacinaIsNull) {
                    funVacinaNull();
                    funLimparCamposVacina();
                    funAtivarCamposVacina();
                } else {
                    funEsconderAllVacinas();
                    funMostrarVacinas();
                }

            }
        }) {
            @Override
            public void onItemClick(MainAdapterVacina model) {

            }
        };

        mainAdapterCartao = new MainAdapterCartaoVacina(getActivity(), mainModelsCartao, new MainAdapterCartaoVacina.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelCartaoVacina model) {
                idCartaoClicado = Integer.valueOf(model.getListaIdCartao());
                nomeVacinaClicada = model.getListaNomeVacina();

                try {
                    Connection con = ConexaoMysql.conectar();
                    String sql = "SELECT * FROM view_cartao_vacinacao WHERE id_cartao_vacinacao = ?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setInt(1, idCartaoClicado);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        nome_vacina.setText(rs.getString("nome_vacina"));

                        Date dataNascimento = rs.getDate("dt_vacinacao");
                        if (dataNascimento != null) {
                            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                            String dataFormatada = formato.format(dataNascimento);
                            dt_vacinacao.setText(dataFormatada);
                        }

                        lote_vacina.setText(rs.getString("lote_vacina"));
                        medico_vet.setText(rs.getString("medico_vet"));
                        clinica_vet.setText(rs.getString("clinica_vet"));
                    }

                    rs.close();
                    stmt.close();
                    con.close();

                    funMostrarLayoutVacina();
                    funDesativarCamposVacina();

                } catch (Exception e) {
                    e.printStackTrace();
                    // Lança uma exceção personalizada ou trata o erro conforme necessário
                    throw new RuntimeException("Erro ao buscar detalhes da vacina", e);
                }
            }
        });

        mainAdapterLista = new MainAdapterLista(getActivity(), mainModelsPets, new MainAdapterLista.OnItemClickListener() {
            @Override
            public void onItemClick(MainModelLista model) {
                idCartaoClicado = model.getListaIdCartaoVac1();
                idPetClicadoVac = model.getListaIdPetVac1();
                nomeVacinaClicada = model.getListaNomeVacinaVac1();

                try {
                    Connection con = ConexaoMysql.conectar();
                    String sql = "SELECT * FROM view_cartao_vacinacao WHERE id_cartao_vacinacao = ?";
                    PreparedStatement stmt = con.prepareStatement(sql);
                    stmt.setInt(1, idCartaoClicado);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        nome_vacina.setText(rs.getString("nome_vacina"));

                        Date dataNascimento = rs.getDate("dt_vacinacao");
                        if (dataNascimento != null) {
                            SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
                            String dataFormatada = formato.format(dataNascimento);
                            dt_vacinacao.setText(dataFormatada);
                        }

                        lote_vacina.setText(rs.getString("lote_vacina"));
                        medico_vet.setText(rs.getString("medico_vet"));
                        clinica_vet.setText(rs.getString("clinica_vet"));
                    }

                    rs.close();
                    stmt.close();
                    con.close();

                    funListaPetsClick();
                    funEsconderAllVacinas();
                    funMostrarLayoutVacina();
                    funDesativarCamposVacina();

                } catch (Exception e) {
                    e.printStackTrace();
                    // Lança uma exceção personalizada ou trata o erro conforme necessário
                    throw new RuntimeException("Erro ao buscar detalhes da vacina na lista de pets", e);
                }
            }
        });

        listaVacina.setAdapter(mainAdapter);
        listaCartaoVacina.setAdapter(mainAdapterCartao);
        listaPets.setAdapter(mainAdapterLista);

        filtrarEspecieVac.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (primeiraSelecaoSpinner) {
                    primeiraSelecaoSpinner = false; // ignora a primeira seleção
                    return;
                }

                String especieSelecionada = filtrarEspecieVac.getSelectedItem().toString();

                // Verifica se a espécie selecionada é diferente da última seleção
                if (!especieSelecionada.equals(ultimaEspecieSelecionada)) {
                    ultimaEspecieSelecionada = especieSelecionada;

                    try {
                        Connection con = ConexaoMysql.conectar();
                        String sql = "SELECT id_pet, nome, foto FROM pet WHERE fk_id_tutor = ? AND especie = ?";
                        PreparedStatement stmt = con.prepareStatement(sql);
                        stmt.setInt(1, idUsuarioAtual);
                        stmt.setString(2, especieSelecionada);
                        ResultSet rs = stmt.executeQuery();

                        // Limpar as listas antes de adicionar novos dados
                        listaIdPetVac.clear();
                        listaNomePetVac.clear();
                        listaFotoPetVac.clear();

                        // Preencher as listas com dados do banco
                        while (rs.next()) {
                            String id1 = rs.getString("id_pet");
                            String nome = rs.getString("nome");
                            byte[] fotoBytes = rs.getBytes("foto");

                            // Converter a foto para Bitmap
                            Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                            // Chama o método para arredondar a imagem
                            Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                            // Adicionar os dados nas listas
                            listaIdPetVac.add(id1);
                            listaNomePetVac.add(nome);
                            listaFotoPetVac.add(roundedBitmap);
                        }

                        rs.close();
                        stmt.close();
                        con.close();

                        // Atualize o RecyclerView com os dados filtrados
                        updateRecyclerView();

                        funMostrarAllVacinas();
                        //funStartLayout();

                    } catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btSalvarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nome_vacina.getText().toString().trim();
                String data = dt_vacinacao.getText().toString().trim();

                if (nome.isEmpty()) {
                    nome_vacina.setError("campo obrigatório");
                    return;
                }

                if (data.isEmpty()) {
                    dt_vacinacao.setError("campo obrigatório");
                    return;
                }

                funAdicionarCartao();

            }
        });

        btAddNovaVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funMostrarListaVacina();
                funLimparCamposVacina();
                funAtivarCamposVacina();
            }
        });

        btAlterarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                funAtivarCamposVacina();
                btAlterarVacina.setVisibility(GONE);
                btSalvarVacina.setVisibility(GONE);
                btAtualizarVacina.setVisibility(VISIBLE);
            }
        });

        btDeletarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage("Confirme para excluir a vacina " +nomeVacinaClicada+".")
                        .setCancelable(false) // Não permite fechar o Dialog clicando fora dele
                        .setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Confirmar"
                                funDeletarCartao();
                            }
                        })
                        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // Ação ao clicar em "Cancelar"
                            }
                        });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        btAtualizarVacina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = nome_vacina.getText().toString().trim();
                String data = dt_vacinacao.getText().toString().trim();

                if (nome.isEmpty()) {
                    nome_vacina.setError("campo obrigatório");
                    return;
                }

                if (data.isEmpty()) {
                    dt_vacinacao.setError("campo obrigatório");
                    return;
                }

                funAtualizarCartao();

            }
        });

        return view;
    }

    @Override
    public void onStart() {
        super.onStart();

        emailUsuarioAtual = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_login FROM login WHERE email = ?;";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1, emailUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                idUsuarioAtual = Integer.valueOf(rs.getString("id_login"));
            }

            rs.close();
            stmt.close();
            con.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        funListaPets(); // Primeiro carrega os pets
        funListaAllVacinas();
        funFiltrarEspecie();

        if (vacinaIsNull) {
            funEsconderAllVacinas();
        } else {
            funMostrarAllVacinas();
        }

        if (petIsNull) {
            funPetNull(); // Chama se não houver pets
        } else {
            funStartLayout();
        }

    }

    public static class DateValidator {

        /* Verifica se a string está no formato dd/MM/yyyy e é uma data possível. */
        public static boolean isValidDate(String dateStr) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            sdf.setLenient(false);           // NÃO aceita 32/13/2025 …

            try {
                Date date = sdf.parse(dateStr);

                // Opcional: limite de ano (ajuste se quiser)
                int year = Integer.parseInt(dateStr.substring(6));
                return year >= 1900 && year <= 2100;
            } catch (ParseException | NumberFormatException e) {
                return false;
            }
        }
    }

    public class DateInputFilter implements InputFilter {

        @Override
        public CharSequence filter(CharSequence source, int start, int end,
                                   Spanned dest, int dstart, int dend) {

            // Monta como ficará o texto se aceitarmos a digitação
            StringBuilder builder = new StringBuilder(dest);
            builder.replace(dstart, dend, source.subSequence(start, end).toString());
            String result = builder.toString();

            // Remove barras para validar só os dígitos
            String digits = result.replaceAll("[^\\d]", "");

            // Limite absoluto: 8 dígitos (ddMMyyyy)
            if (digits.length() > 8) return "";

            // Validação incremental: DIA
            if (digits.length() >= 1) {
                int diaDezena = Character.getNumericValue(digits.charAt(0));
                if (diaDezena > 3) return "";
            }
            if (digits.length() >= 2) {
                int dia = Integer.parseInt(digits.substring(0, 2));
                if (dia < 1 || dia > 31) return "";
            }

            // Validação incremental: MÊS
            if (digits.length() >= 4) {
                int mes = Integer.parseInt(digits.substring(2, 4));
                if (mes < 1 || mes > 12) return "";
            }

            // Validação incremental: ANO (opcional)
            if (digits.length() == 8) {
                int ano = Integer.parseInt(digits.substring(4, 8));
                if (ano < 1900 || ano > 2100) return "";
            }

            // Tudo OK: aceita a digitação
            return null;
        }
    }

    public void funListaPets() {
        petIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_pet, nome, foto FROM pet WHERE fk_id_tutor = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdPetVac.clear();
            listaNomePetVac.clear();
            listaFotoPetVac.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_pet");
                String nome = rs.getString("nome");
                byte[] fotoBytes = rs.getBytes("foto");

                // Converter a foto para Bitmap
                Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                // Chama o método para arredondar a imagem
                Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                // Adicionar os dados nas listas
                listaIdPetVac.add(id);
                listaNomePetVac.add(nome);
                listaFotoPetVac.add(roundedBitmap);

                petIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            // Atualize o RecyclerView com os dados
            updateRecyclerView();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void funListaPetsClick() {
        petIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT id_pet, nome, foto FROM pet WHERE id_pet = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idPetClicadoVac);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdPetVac.clear();
            listaNomePetVac.clear();
            listaFotoPetVac.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_pet");
                String nome = rs.getString("nome");
                byte[] fotoBytes = rs.getBytes("foto");

                // Converter a foto para Bitmap
                Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                // Chama o método para arredondar a imagem
                Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                // Adicionar os dados nas listas
                listaIdPetVac.add(id);
                listaNomePetVac.add(nome);
                listaFotoPetVac.add(roundedBitmap);

                petIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            // Atualize o RecyclerView com os dados
            updateRecyclerView();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateRecyclerView() {
        // Atualizar o adapter com os novos dados
        mainModels.clear(); // Limpar a lista antiga
        for (int i = 0; i < listaIdPetVac.size(); i++) {
            MainModelVacina model = new MainModelVacina(listaFotoPetVac.get(i), listaNomePetVac.get(i), listaIdPetVac.get(i));
            mainModels.add(model);
        }

        // Notificar o adapter sobre a mudança nos dados
        mainAdapter.notifyDataSetChanged();
    }

    public void updateRecyclerViewCartao() {
        mainModelsCartao.clear();
        for (int i = 0; i < listaIdCartao.size(); i++) {
            MainModelCartaoVacina model = new MainModelCartaoVacina(listaIdCartao.get(i), listaNomeCartao.get(i), listadtVacina.get(i));
            mainModelsCartao.add(model);
        }

        if (mainAdapterCartao == null) {
            mainAdapterCartao = new MainAdapterCartaoVacina(getContext(), mainModelsCartao, new MainAdapterCartaoVacina.OnItemClickListener() {
                @Override
                public void onItemClick(MainModelCartaoVacina model) {
                    // Aqui você trata o clique do item
                }
            });
            listaCartaoVacina.setAdapter(mainAdapterCartao);
        } else {
            mainAdapterCartao.notifyDataSetChanged();
        }
    }

    public void updateRecyclerAllVacina() {
        mainModelsPets.clear();

        // Verifica se todas as listas estão preenchidas e do mesmo tamanho
        if (listaIdPetVac1.isEmpty() ||
                listaNomePetVac1.isEmpty() ||
                listaNomeVacinaVac1.isEmpty() ||
                listaDtVacinaVac1.isEmpty()) {

            Toast.makeText(getActivity(), "\"Uma ou mais listas estão vazias\"", Toast.LENGTH_SHORT).show();
            return; // Sai para evitar IndexOutOfBoundsException
        }

        int size = listaIdPetVac1.size();

        // Garante que todas têm o mesmo tamanho
        if (listaNomePetVac1.size() != size ||
                listaNomeVacinaVac1.size() != size ||
                listaDtVacinaVac1.size() != size) {

            Toast.makeText(getActivity(), "\"updateRecyclerAllVacina\", \"Tamanhos das listas são diferentes!\"", Toast.LENGTH_SHORT).show();
            return;
        }

        for (int i = 0; i < size; i++) {
            MainModelLista model = new MainModelLista(
                    listaIdPetVac1.get(i),
                    listaIdCartaoVac1.get(i),
                    listaFotoPetVac1.get(i),
                    listaNomePetVac1.get(i),
                    listaNomeVacinaVac1.get(i),
                    listaDtVacinaVac1.get(i)
            );
            mainModelsPets.add(model);
        }

        if (mainAdapterLista == null) {
            mainAdapterLista = new MainAdapterLista(getContext(), mainModelsPets, new MainAdapterLista.OnItemClickListener() {
                @Override
                public void onItemClick(MainModelLista model) {
                    // clique
                }
            });
            listaPets.setAdapter(mainAdapterLista);
        } else {
            mainAdapterLista.notifyDataSetChanged();
        }
    }

    public Bitmap getRoundedBitmap(Bitmap bitmap) {
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();
        int diameter = Math.min(width, height); // Tamanho do círculo

        // Criar um Bitmap novo com fundo transparente
        Bitmap output = Bitmap.createBitmap(diameter, diameter, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(output);

        // Criar um Paint com bordas suaves
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        // Desenhar um círculo na área onde queremos a imagem
        canvas.drawARGB(0, 0, 0, 0); // Fundo transparente
        canvas.drawCircle(diameter / 2, diameter / 2, diameter / 2, paint);

        // Usar a imagem com um efeito de máscara circular
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
        canvas.drawBitmap(bitmap, (diameter - width) / 2, (diameter - height) / 2, paint);

        return output;
    }

    public void funFiltrarEspecie() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT DISTINCT especie FROM pet WHERE fk_id_tutor = ? ORDER BY especie ASC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            // Criar uma lista de String para o Spinner
            List<String> filtrarEspecieList = new ArrayList<>();

            while (rs.next()) {
                filtrarEspecieList.add(rs.getString("especie"));
            }

            // Criar o ArrayAdapter e associar ao Spinner
            ArrayAdapter<String> adapter2 = new ArrayAdapter<>(getActivity(), R.layout.spinner_item, filtrarEspecieList);
            adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            filtrarEspecieVac.setAdapter(adapter2);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funAdicionarCartao() {
        // 1. Captura e limpeza dos campos
        String nome    = nome_vacina.getText().toString().trim();
        String dataStr = dt_vacinacao.getText().toString().trim();

        // 2. Validações de obrigatoriedade
        if (nome.isEmpty())   { nome_vacina.setError("Campo obrigatório");   return; }
        if (dataStr.isEmpty()){ dt_vacinacao.setError("Campo obrigatório");  return; }

        // 3. Validação de formato/consistência da data
        if (!DateValidator.isValidDate(dataStr)) {
            dt_vacinacao.setError("Data inválida");
            return;
        }

        // 4. Conversão segura String para java.sql.Date
        java.sql.Date dataSql;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            dataSql = new java.sql.Date(sdf.parse(dataStr).getTime());
        } catch (ParseException e) {
            // Só deve ocorrer em caso de erro muito improvável
            dt_vacinacao.setError("Data inválida");
            Toast.makeText(getActivity(), "Erro ao converter a data", Toast.LENGTH_SHORT).show();
            return;
        }

        // 5. Inserir no banco
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "INSERT INTO cartao_vacinacao (nome_vacina, dt_vacinacao, lote_vacina, medico_vet, clinica_vet, fk_id_pet)" +
                    "VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);

            stmt.setString(1, nome_vacina.getText().toString().trim());
            stmt.setDate(2, dataSql);
            stmt.setString(3, lote_vacina.getText().toString().trim());
            stmt.setString(4, medico_vet.getText().toString().trim());
            stmt.setString(5, clinica_vet.getText().toString().trim());
            stmt.setInt(6, idPetClicadoVac);
            stmt.executeUpdate();

            stmt.close();
            con.close();

            // 6. UI pós-atualização
            funListaCartao();
            funLimparCamposVacina();
            funEsconderListaVacina();

        } catch (Exception e) {
            Toast.makeText(getActivity(), "Erro ao adicionar a vacina", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    public void funAtualizarCartao() {

        // 1. Captura e limpeza dos campos
        String nome    = nome_vacina.getText().toString().trim();
        String dataStr = dt_vacinacao.getText().toString().trim();
        String lote    = lote_vacina.getText().toString().trim();
        String medico  = medico_vet.getText().toString().trim();
        String clinica = clinica_vet.getText().toString().trim();

        // 2. Validações de obrigatoriedade
        if (nome.isEmpty())   { nome_vacina.setError("Campo obrigatório");   return; }
        if (dataStr.isEmpty()){ dt_vacinacao.setError("Campo obrigatório");  return; }

        // 3. Validação de formato/consistência da data
        if (!DateValidator.isValidDate(dataStr)) {
            dt_vacinacao.setError("Data inválida");
            return;
        }

        // 4. Conversão segura String para java.sql.Date
        java.sql.Date dataSql;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            dataSql = new java.sql.Date(sdf.parse(dataStr).getTime());
        } catch (ParseException e) {
            // Só deve ocorrer em caso de erro muito improvável
            dt_vacinacao.setError("Data inválida");
            Toast.makeText(getActivity(), "Erro ao converter a data", Toast.LENGTH_SHORT).show();
            return;
        }

        // 5. Atualiza no banco
        try (Connection con = ConexaoMysql.conectar();
             PreparedStatement stmt = con.prepareStatement(
                     "UPDATE cartao_vacinacao SET nome_vacina = ?, dt_vacinacao = ?, " +
                             "lote_vacina = ?, medico_vet = ?, clinica_vet = ? WHERE id_cartao_vacinacao = ?")) {

            stmt.setString(1, nome);
            stmt.setDate  (2, dataSql);
            stmt.setString(3, lote);
            stmt.setString(4, medico);
            stmt.setString(5, clinica);
            stmt.setInt   (6, idCartaoClicado);

            stmt.executeUpdate();

            // 6. UI pós-atualização
            funListaCartao();
            funLimparCamposVacina();
            funEsconderListaVacina();

        } catch (Exception e) {
            Toast.makeText(getActivity(), "Erro ao atualizar a vacina", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }


    public void funDeletarCartao() {
        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "DELETE FROM cartao_vacinacao WHERE id_cartao_vacinacao = ?";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idCartaoClicado);
            stmt.executeUpdate();

            stmt.close();
            con.close();

            funListaCartao();
            funLimparCamposVacina();

            if (vacinaIsNull) {
                funStartLayout();
            } else {
                funListaCartao();
                funEsconderListaVacina();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funListaCartao() {
        vacinaIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_pet = ? ORDER BY dt_vacinacao DESC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idPetClicadoVac);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdCartao.clear();
            listaNomeCartao.clear();
            listadtVacina.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_cartao_vacinacao");
                String nome = rs.getString("nome_vacina");

                // Formatar a data
                Date data = rs.getDate("dt_vacinacao");
                String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                // Adicionar os dados nas listas
                listaIdCartao.add(id);
                listaNomeCartao.add(nome);
                listadtVacina.add(dataFormatada);

                vacinaIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            if (!vacinaIsNull) {
                updateRecyclerViewCartao();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funListaAllVacinas() {
        vacinaIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_tutor = ? ORDER BY dt_vacinacao DESC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdPetVac1.clear();
            listaIdCartaoVac1.clear();
            listaNomePetVac1.clear();
            listaNomeVacinaVac1.clear();
            listaDtVacinaVac1.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                Integer idPet = rs.getInt("fk_id_pet");
                Integer idCartao = rs.getInt("id_cartao_vacinacao");
                String nomePet = rs.getString("nome_pet");
                byte[] fotoBytes = rs.getBytes("foto");

                // Converter a foto para Bitmap
                Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                // Chama o método para arredondar a imagem
                Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                String nome = rs.getString("nome_vacina");

                // Formatar a data
                Date data = rs.getDate("dt_vacinacao");
                String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                Log.d("VacinaDebug", "ID: "+idPet+ "Nome: "+ nomePet + ", Vacina: " + nome + ", Data: " + dataFormatada);


                // Adicionar os dados nas listas
                listaIdPetVac1.add(idPet);
                listaIdCartaoVac1.add(idCartao);
                listaNomePetVac1.add(nomePet);
                listaFotoPetVac1.add(roundedBitmap);
                listaNomeVacinaVac1.add(nome);
                listaDtVacinaVac1.add(dataFormatada);

                vacinaIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            if (!vacinaIsNull) {
                updateRecyclerAllVacina();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funListaCartaoProximas() {
        vacinaIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_pet = ? AND dt_vacinacao >= CURRENT_DATE " +
                    "ORDER BY dt_vacinacao DESC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idPetClicadoVac);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdCartao.clear();
            listaNomeCartao.clear();
            listadtVacina.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_cartao_vacinacao");
                String nome = rs.getString("nome_vacina");

                // Formatar a data
                Date data = rs.getDate("dt_vacinacao");
                String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                // Adicionar os dados nas listas
                listaIdCartao.add(id);
                listaNomeCartao.add(nome);
                listadtVacina.add(dataFormatada);

                vacinaIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            if (!vacinaIsNull) {
                updateRecyclerViewCartao();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funListaCartaoProximasAll() {
        vacinaIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_tutor = ? AND dt_vacinacao >= CURRENT_DATE " +
                    "ORDER BY dt_vacinacao DESC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdPetVac1.clear();
            listaIdCartaoVac1.clear();
            listaNomePetVac1.clear();
            listaNomeVacinaVac1.clear();
            listaDtVacinaVac1.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                Integer idPet = rs.getInt("fk_id_pet");
                Integer idCartao = rs.getInt("id_cartao_vacinacao");
                String nomePet = rs.getString("nome_pet");
                byte[] fotoBytes = rs.getBytes("foto");

                // Converter a foto para Bitmap
                Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                // Chama o método para arredondar a imagem
                Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                String nome = rs.getString("nome_vacina");

                // Formatar a data
                Date data = rs.getDate("dt_vacinacao");
                String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                Log.d("VacinaDebug", "ID: "+idPet+ "Nome: "+ nomePet + ", Vacina: " + nome + ", Data: " + dataFormatada);


                // Adicionar os dados nas listas
                listaIdPetVac1.add(idPet);
                listaIdCartaoVac1.add(idCartao);
                listaNomePetVac1.add(nomePet);
                listaFotoPetVac1.add(roundedBitmap);
                listaNomeVacinaVac1.add(nome);
                listaDtVacinaVac1.add(dataFormatada);

                vacinaIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            if (!vacinaIsNull) {
                updateRecyclerAllVacina();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funListaCartaoAplicadas() {
        vacinaIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_pet = ? AND dt_vacinacao < CURRENT_DATE " +
                    "ORDER BY dt_vacinacao DESC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idPetClicadoVac);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdCartao.clear();
            listaNomeCartao.clear();
            listadtVacina.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                String id = rs.getString("id_cartao_vacinacao");
                String nome = rs.getString("nome_vacina");

                // Formatar a data
                Date data = rs.getDate("dt_vacinacao");
                String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                // Adicionar os dados nas listas
                listaIdCartao.add(id);
                listaNomeCartao.add(nome);
                listadtVacina.add(dataFormatada);

                vacinaIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            if (!vacinaIsNull) {
                updateRecyclerViewCartao();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funListaCartaoAplicadasAll() {
        vacinaIsNull = true;

        try {
            Connection con = ConexaoMysql.conectar();
            String sql = "SELECT * FROM view_cartao_vacinacao WHERE fk_id_tutor = ? AND dt_vacinacao < CURRENT_DATE " +
                    "ORDER BY dt_vacinacao DESC";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setInt(1, idUsuarioAtual);
            ResultSet rs = stmt.executeQuery();

            // Limpar as listas antes de adicionar novos dados
            listaIdPetVac1.clear();
            listaIdCartaoVac1.clear();
            listaNomePetVac1.clear();
            listaNomeVacinaVac1.clear();
            listaDtVacinaVac1.clear();

            // Preencher as listas com dados do banco
            while (rs.next()) {
                Integer idPet = rs.getInt("fk_id_pet");
                Integer idCartao = rs.getInt("id_cartao_vacinacao");
                String nomePet = rs.getString("nome_pet");
                byte[] fotoBytes = rs.getBytes("foto");

                // Converter a foto para Bitmap
                Bitmap fotoBitmap = BitmapFactory.decodeByteArray(fotoBytes, 0, fotoBytes.length);

                // Chama o método para arredondar a imagem
                Bitmap roundedBitmap = getRoundedBitmap(fotoBitmap);

                String nome = rs.getString("nome_vacina");

                // Formatar a data
                Date data = rs.getDate("dt_vacinacao");
                String dataFormatada = new SimpleDateFormat("dd/MM/yyyy").format(data);

                Log.d("VacinaDebug", "ID: "+idPet+ "Nome: "+ nomePet + ", Vacina: " + nome + ", Data: " + dataFormatada);


                // Adicionar os dados nas listas
                listaIdPetVac1.add(idPet);
                listaIdCartaoVac1.add(idCartao);
                listaNomePetVac1.add(nomePet);
                listaFotoPetVac1.add(roundedBitmap);
                listaNomeVacinaVac1.add(nome);
                listaDtVacinaVac1.add(dataFormatada);

                vacinaIsNull = false;
            }

            // Fechar os recursos
            rs.close();
            stmt.close();
            con.close();

            if (!vacinaIsNull) {
                updateRecyclerAllVacina();
            }

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void funAtivarCamposVacina() {
        nome_vacina.setEnabled(true);
        lote_vacina.setEnabled(true);
        dt_vacinacao.setEnabled(true);
        medico_vet.setEnabled(true);
        clinica_vet.setEnabled(true);
    }

    public void funDesativarCamposVacina() {
        nome_vacina.setEnabled(false);
        lote_vacina.setEnabled(false);
        dt_vacinacao.setEnabled(false);
        medico_vet.setEnabled(false);
        clinica_vet.setEnabled(false);

        nome_vacina.setError(null);
        dt_vacinacao.setError(null);
    }

    public void funEsconderListaVacina() {
        tvVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        spinnerFiltrarVacinasClick.setVisibility(VISIBLE);
        tvVacinas.setVisibility(VISIBLE);
        btAddNovaVacina.setVisibility(VISIBLE);
        listaCartaoVacina.setVisibility(VISIBLE);
    }

    public void funMostrarListaVacina() {
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        tvNovaVacina.setVisibility(VISIBLE);
        nome_vacina.setVisibility(VISIBLE);
        lote_vacina.setVisibility(VISIBLE);
        dt_vacinacao.setVisibility(VISIBLE);
        medico_vet.setVisibility(VISIBLE);
        clinica_vet.setVisibility(VISIBLE);
        btSalvarVacina.setVisibility(VISIBLE);
        tvNomeVacina.setVisibility(VISIBLE);
        tvLoteVacina.setVisibility(VISIBLE);
        tvDataVacina.setVisibility(VISIBLE);
        tvMedicoVet.setVisibility(VISIBLE);
        tvClinicaVet.setVisibility(VISIBLE);

        tvFiltrarEspecieVac.setVisibility(VISIBLE);
        filtrarEspecieVac.setVisibility(VISIBLE);
        listaVacina.setVisibility(VISIBLE);
    }

    public void funLimparCamposVacina() {
        nome_vacina.setText(null);
        lote_vacina.setText(null);
        dt_vacinacao.setText(null);
        medico_vet.setText(null);
        clinica_vet.setText(null);
        nome_vacina.setError(null);
        dt_vacinacao.setError(null);
    }

    public void funPetNull() {
        btAddNovaVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);

        // Oculta o RecyclerView de pets e cartões de vacina
        listaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);

        // Oculta spinner
        if (filtrarEspecieVac != null) {
            filtrarEspecieVac.setVisibility(GONE);
        }
        tvFiltrarEspecieVac.setVisibility(GONE);

        // Mostra uma mensagem informando que o usuário não tem pets cadastrados
        tvPetNull.setVisibility(VISIBLE);
        tvPetNull.setText("Você ainda não cadastrou nenhum PET.");
    }

    public void funVacinaNull() {
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        tvPetNull.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        listaPets.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        tvNovaVacina.setVisibility(VISIBLE);
        nome_vacina.setVisibility(VISIBLE);
        dt_vacinacao.setVisibility(VISIBLE);
        lote_vacina.setVisibility(VISIBLE);
        medico_vet.setVisibility(VISIBLE);
        clinica_vet.setVisibility(VISIBLE);
        btSalvarVacina.setVisibility(VISIBLE);
        tvNomeVacina.setVisibility(VISIBLE);
        tvLoteVacina.setVisibility(VISIBLE);
        tvDataVacina.setVisibility(VISIBLE);
        tvMedicoVet.setVisibility(VISIBLE);
        tvClinicaVet.setVisibility(VISIBLE);
    }

    public void funStartLayout() {
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
    }

    public void funMostrarVacinas() {
        tvVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        spinnerFiltrarVacinasClick.setVisibility(VISIBLE);
        tvVacinas.setVisibility(VISIBLE);
        btAddNovaVacina.setVisibility(VISIBLE);
        listaCartaoVacina.setVisibility(VISIBLE);
    }

    public void funMostrarLayoutVacina() {
        btSalvarVacina.setVisibility(GONE);
        tvPetNull.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
        tvVacina.setVisibility(VISIBLE);
        nome_vacina.setVisibility(VISIBLE);
        dt_vacinacao.setVisibility(VISIBLE);
        lote_vacina.setVisibility(VISIBLE);
        medico_vet.setVisibility(VISIBLE);
        clinica_vet.setVisibility(VISIBLE);
        tvNomeVacina.setVisibility(VISIBLE);
        tvLoteVacina.setVisibility(VISIBLE);
        tvDataVacina.setVisibility(VISIBLE);
        tvMedicoVet.setVisibility(VISIBLE);
        tvClinicaVet.setVisibility(VISIBLE);
        btAlterarVacina.setVisibility(VISIBLE);
        btDeletarVacina.setVisibility(VISIBLE);
    }

    public void funMostrarAllVacinas() {
        spinnerFiltrarVacinasClick.setVisibility(GONE);
        tvVacina.setVisibility(GONE);
        nome_vacina.setVisibility(GONE);
        lote_vacina.setVisibility(GONE);
        dt_vacinacao.setVisibility(GONE);
        medico_vet.setVisibility(GONE);
        clinica_vet.setVisibility(GONE);
        btSalvarVacina.setVisibility(GONE);
        btAddNovaVacina.setVisibility(GONE);
        listaCartaoVacina.setVisibility(GONE);
        tvNovaVacina.setVisibility(GONE);
        btAlterarVacina.setVisibility(GONE);
        btAtualizarVacina.setVisibility(GONE);
        btDeletarVacina.setVisibility(GONE);
        tvNomeVacina.setVisibility(GONE);
        tvLoteVacina.setVisibility(GONE);
        tvDataVacina.setVisibility(GONE);
        tvMedicoVet.setVisibility(GONE);
        tvClinicaVet.setVisibility(GONE);
        listaPets.setVisibility(VISIBLE);
        tvVacinas.setVisibility(VISIBLE);
        spinnerFiltrarAllVacinas.setVisibility(VISIBLE);
        spinnerFiltrarAllVacinas.setSelection(0);
        funListaAllVacinas();
    }

    public void funEsconderAllVacinas() {
        listaPets.setVisibility(GONE);
        tvVacinas.setVisibility(GONE);
        spinnerFiltrarAllVacinas.setVisibility(GONE);
    }

}